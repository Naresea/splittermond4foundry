import { ATTRIBUTES } from "../models/actors/attributes.js";
import { DERIVED_ATTRIBUTES, } from "../models/actors/derived-attributes.js";
import { ModifierService } from "./modifier-service.js";
import { ModifierType } from "../models/items/modifier.js";
import { PlayerDataService } from "./player-data-service.js";
export class CalculationService {
    static getInitiative(actor) {
        var _a;
        if (actor.data.type === "PlayerCharacter" /* PlayerCharacter */) {
            const data = PlayerDataService.getPlayerData(actor);
            return data.derivedAttributes.INI.total;
        }
        else {
            const modifiers = ModifierService.getModifiers(actor);
            const iniMod = ModifierService.totalMod(modifiers, "INI", {
                modType: ModifierType.Attribute,
            });
            return ((_a = actor.data.data.INI) !== null && _a !== void 0 ? _a : 0) + iniMod;
        }
    }
    static getAttributeValue(actor, attribute, mods) {
        var _a, _b, _c;
        if (!ATTRIBUTES.includes(attribute) &&
            !DERIVED_ATTRIBUTES.includes(attribute)) {
            return {
                total: 0,
                explanation: "No attribute",
            };
        }
        const startValue = (_a = actor.data.data[attribute]) !== null && _a !== void 0 ? _a : 0;
        const increasedValue = (_b = actor.data.data["inc" + attribute]) !== null && _b !== void 0 ? _b : 0;
        const modifierValue = (_c = ModifierService.totalMod(mods, attribute, {
            modType: ModifierType.Attribute,
        })) !== null && _c !== void 0 ? _c : 0;
        const total = startValue + increasedValue + modifierValue;
        return {
            total,
            explanation: `Start ${startValue} + Erhöht ${increasedValue} + Mod ${modifierValue}`,
        };
    }
    static getFertigkeitsValue(actor, fertigkeit, mods) {
        const fertigkeitItem = actor.items.find((item) => item.type === "fertigkeit" /* Fertigkeit */ && item.name === fertigkeit);
        if (!fertigkeitItem) {
            return {
                total: 0,
                explanation: "Keine Fertigkeit",
            };
        }
        const attrEins = CalculationService.getAttributeValue(actor, fertigkeitItem.data.data.attributEins, mods).total;
        const attrZwei = CalculationService.getAttributeValue(actor, fertigkeitItem.data.data.attributZwei, mods).total;
        const mod = ModifierService.totalMod(mods, fertigkeit, {
            modType: ModifierType.Fertigkeit,
        });
        const total = attrEins +
            attrZwei +
            mod +
            fertigkeitItem.data.data.punkte +
            fertigkeitItem.data.data.mod;
        return {
            total,
            explanation: `${fertigkeitItem.data.data.attributEins} ${attrEins} + ${fertigkeitItem.data.data.attributZwei} ${attrZwei} + ${fertigkeitItem.name} ${fertigkeitItem.data.data.punkte} + Mod ${fertigkeitItem.data.data.mod}`,
        };
    }
    static getWaffeOrSchildValue(actor, waffe, mods, name) {
        const fertigkeitItem = actor.items.find((item) => item.type === "fertigkeit" /* Fertigkeit */ && item.name === waffe.fertigkeit);
        const attrEins = CalculationService.getAttributeValue(actor, waffe.attribute, mods).total;
        const attrZwei = CalculationService.getAttributeValue(actor, waffe.attributeSecondary, mods).total;
        let total = attrEins + attrZwei + waffe.mod;
        let explanation = `Waffe ${name ? `(${name})` : ""} ${waffe.mod} + ${waffe.attribute} ${attrEins} + ${waffe.attributeSecondary} ${attrZwei}`;
        if (!fertigkeitItem) {
            return {
                total,
                explanation,
            };
        }
        const fertigkeitVal = fertigkeitItem.data.data.punkte + fertigkeitItem.data.data.mod;
        const fertigkeitMod = ModifierService.totalMod(mods, fertigkeitItem.name, {
            modType: ModifierType.Fertigkeit,
        });
        explanation += ` + ${waffe.fertigkeit} ${fertigkeitVal + fertigkeitMod}`;
        total += fertigkeitVal + fertigkeitMod;
        return {
            total,
            explanation,
        };
    }
    static async updateWoundModifier(actor) {
        var _a, _b;
        const modName = game.i18n.localize(CalculationService.WOUND_MODIFIER_ID);
        const internalId = CalculationService.WOUND_MODIFIER_ID;
        const modifiers = ModifierService.getModifiers(actor);
        // Only "verzehrt" counts towards wound modifiers
        const healthVerzehrt = actor.data.data.healthVerzehrt;
        let hpPerWoundLevel = actor.data.data.LP;
        if (actor.data.type === "PlayerCharacter") {
            const attributes = PlayerDataService.getAttributes(actor, modifiers);
            const derivedAttributes = PlayerDataService.getDerivedAttributes(actor, modifiers, attributes);
            hpPerWoundLevel = derivedAttributes.LP.total;
        }
        const numWoundLevels = actor.data.data.woundLevel.max +
            ModifierService.totalMod(modifiers, null, {
                modType: ModifierType.WoundLevels,
            });
        const lostHpLevels = Math.max(0, Math.min(numWoundLevels + 1, Math.floor((healthVerzehrt - 1) / hpPerWoundLevel)));
        const modifierLists = numWoundLevels <= 1
            ? [
                { name: "Unverletzt", mod: 0 },
                { name: "Sterbend", mod: -8 },
                { name: "Tod", mod: -8 },
            ]
            : numWoundLevels <= 3
                ? [
                    { name: "Unverletzt", mod: 0 },
                    { name: "Verletzt", mod: -2 },
                    { name: "Todgeweiht", mod: -8 },
                    { name: "Sterbend", mod: -8 },
                    { name: "Tod", mod: -8 },
                ]
                : [
                    { name: "Unverletzt", mod: 0 },
                    { name: "Angeschlagen", mod: -1 },
                    { name: "Verletzt", mod: -2 },
                    { name: "SchwerVerletzt", mod: -4 },
                    { name: "Todgeweiht", mod: -8 },
                    { name: "Sterbend", mod: -8 },
                    { name: "Tod", mod: -8 },
                ];
        const modifier = modifierLists[lostHpLevels];
        const affectedSkills = actor.items
            .filter((i) => i.type === "fertigkeit" /* Fertigkeit */)
            .map((i) => i.name);
        const skillModifiers = affectedSkills.map((skillName) => {
            var _a;
            return ({
                type: ModifierType.Fertigkeit,
                target: skillName,
                value: (_a = modifier === null || modifier === void 0 ? void 0 : modifier.mod) !== null && _a !== void 0 ? _a : 0,
            });
        });
        const initMod = {
            type: ModifierType.Attribute,
            target: "INI",
            value: Math.abs((_a = modifier === null || modifier === void 0 ? void 0 : modifier.mod) !== null && _a !== void 0 ? _a : 0),
        };
        const gwsMod = {
            type: ModifierType.Attribute,
            target: "GSW",
            value: (_b = modifier === null || modifier === void 0 ? void 0 : modifier.mod) !== null && _b !== void 0 ? _b : 0,
        };
        const zustandModifiers = [...skillModifiers, initMod, gwsMod];
        const ids = actor.items
            .filter((i) => i.type === "zustand" /* Zustand */ &&
            i.data.data.internalId === internalId)
            .map((i) => i._id);
        await actor.deleteEmbeddedEntity("OwnedItem", ids);
        await actor.createOwnedItem({
            type: "zustand" /* Zustand */,
            name: modName,
            data: {
                modifier: zustandModifiers,
                beschreibung: game.i18n.localize(`splittermond.woundmodifier.${modifier.name}`),
                regelwerk: "GRW",
                internalId: internalId,
                seite: 172,
            },
        });
    }
    static fromEKVString(ekvString) {
        const kanalisiertMatch = ekvString.match(/[Kk]\d+/);
        const kanalisiert = kanalisiertMatch
            ? +kanalisiertMatch[0].replace(/[Kk]/, "")
            : 0;
        const verzehrtMatch = ekvString.match(/[Vv]\d+/);
        const verzehrt = verzehrtMatch ? +verzehrtMatch[0].replace(/[Vv]/, "") : 0;
        const erschoepftMatch = ekvString.match(/\d+/);
        const erschoepft = erschoepftMatch ? +erschoepftMatch[0] : 0;
        return {
            erschoepft,
            kanalisiert,
            verzehrt,
        };
    }
    static toEKVString(erschoepft, kanalisiert, verzehrt) {
        return `${erschoepft}K${kanalisiert}V${verzehrt}`;
    }
}
CalculationService.WOUND_MODIFIER_ID = "splittermond.woundmodifier.statename";
