export class SplimoItemSheet extends ItemSheet {
}
