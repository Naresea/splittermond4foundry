export class ModifierItemSheet extends FormApplication {
    constructor(object, options, update) {
        super(object, options);
        this.update = update;
    }
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["splittermond"],
            template: "systems/splittermond/templates/sheets/item/modifier-sheet.hbs",
            width: 512,
            height: 766,
            tabs: [
                {
                    navSelector: ".sheet-tabs",
                    contentSelector: ".sheet-body",
                    initial: "description",
                },
            ],
            submitOnChange: true,
            submitOnClose: true,
            closeOnSubmit: false,
            editable: true,
        });
    }
    getData(options) {
        return this.object;
    }
    _updateObject(event, formData) {
        var _a, _b, _c;
        this.object.target = (_a = formData.target) !== null && _a !== void 0 ? _a : this.object.target;
        this.object.value = (_b = formData.value) !== null && _b !== void 0 ? _b : this.object.value;
        this.object.type = (_c = formData.type) !== null && _c !== void 0 ? _c : this.object.type;
        this.render();
        return this.update
            ? this.update(event, formData)
            : Promise.reject("No update defined.");
    }
}
