import { SplimoItemSheet } from "../splimo-item-sheet.js";
import { ModifierType } from "../../models/items/modifier.js";
import { ModifierItemSheet } from "./modifier-item-sheet.js";
export class StaerkeSheet extends SplimoItemSheet {
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["splittermond"],
            template: "systems/splittermond/templates/sheets/item/staerke-sheet.hbs",
            width: 512,
            height: 766,
            tabs: [
                {
                    navSelector: ".sheet-tabs",
                    contentSelector: ".sheet-body",
                    initial: "description",
                },
            ],
        });
    }
    getData() {
        const data = super.getData();
        const modifier = this.item.data.data.modifier.map((mod) => {
            return {
                fields: [mod.type, mod.target, `${mod.value}`],
            };
        });
        data.data.modifier = modifier;
        return data;
    }
    activateListeners(html) {
        super.activateListeners(html);
        this.registerCreateModifierClick(html);
        this.registerEditModifierClick(html);
        this.registerDeleteModifierClick(html);
    }
    registerCreateModifierClick(html) {
        html.find(".staerke-modifier .add-item").on("click", async () => {
            const modifier = {
                value: 2,
                target: "AUS",
                type: ModifierType.Attribute,
            };
            this.item.data.data.modifier.push(modifier);
            const index = this.item.data.data.modifier.length - 1;
            await this.item.update({
                _id: this.item.id,
                data: {
                    modifier: [...this.item.data.data.modifier],
                },
            });
            this.renderModifierSheet(modifier, index);
        });
    }
    registerEditModifierClick(html) {
        html.find(".staerke-modifier .edit-item").on("click", (evt) => {
            const index = +evt.target.dataset.index;
            const modifier = this.item.data.data.modifier[index];
            this.item.update({
                _id: this.item.id,
                data: {
                    modifier: [...this.item.data.data.modifier],
                },
            });
            this.renderModifierSheet(modifier, index);
        });
    }
    renderModifierSheet(modifier, index) {
        new ModifierItemSheet(modifier, {}, (evt, formData) => {
            const item = this.item.data.data.modifier[index];
            item.target = formData.target;
            item.type = formData.type;
            item.value = formData.value;
            return this.item.update({
                _id: this.item.id,
                data: {
                    modifier: [...this.item.data.data.modifier],
                },
            });
        }).render(true);
    }
    registerDeleteModifierClick(html) {
        html.find(".staerke-modifier .delete-item").on("click", (evt) => {
            const index = +evt.target.dataset.index;
            this.item.data.data.modifier.splice(index, 1);
            this.item.update({
                _id: this.item.id,
                data: {
                    modifier: this.item.data.data.modifier,
                },
            });
        });
    }
}
