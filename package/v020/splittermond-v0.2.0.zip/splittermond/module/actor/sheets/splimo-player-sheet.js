import { SplimoActorSheet } from "../splimo-actor-sheet.js";
import { PlayerDataService } from "../../services/player-data-service.js";
import { CalculationService } from "../../services/calculation-service.js";
export class SplimoPlayerSheet extends SplimoActorSheet {
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["splittermond"],
            template: "systems/splittermond/templates/sheets/actor/player-sheet.hbs",
            width: 1024,
            height: 754,
            tabs: [
                {
                    navSelector: ".sheet-tabs",
                    contentSelector: ".sheet-body",
                    initial: "description",
                },
                {
                    navSelector: ".fertigkeiten-tabs",
                    contentSelector: ".fertigkeiten-content",
                    initial: "allgemein",
                },
            ],
        });
    }
    getData() {
        const calcData = PlayerDataService.getPlayerData(this.actor);
        const data = super.getData();
        data.data = calcData;
        console.log("Sheet data: ", data);
        return data;
    }
    _updateObject(event, formData) {
        formData = this.updateViewSpecificData(formData);
        if (formData["data.mondzeichen.beschreibung"]) {
            delete formData["data.mondzeichen.beschreibung"];
        }
        return super._updateObject(event, formData).then(() => {
            return CalculationService.updateWoundModifier(this.actor);
        });
    }
}
