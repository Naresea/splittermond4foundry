export class PortraitSheet {
    static activatePortraitListener(htmlElem, portraitListener) {
        const html = htmlElem instanceof HTMLElement ? $(htmlElem) : htmlElem;
        html.on("click", ".portrait > .portrait-move-icon", (evt) => {
            var _a;
            const dataset = (_a = evt.currentTarget) === null || _a === void 0 ? void 0 : _a.dataset;
            if (!dataset || !dataset["move"]) {
                return;
            }
            const dataMove = dataset["move"];
            switch (dataMove) {
                case "up":
                    portraitListener.savePortraitTransform(PortraitSheet.transformY(portraitListener, -PortraitSheet.moveSpeedPx));
                    break;
                case "down":
                    portraitListener.savePortraitTransform(PortraitSheet.transformY(portraitListener, PortraitSheet.moveSpeedPx));
                    break;
                case "left":
                    portraitListener.savePortraitTransform(PortraitSheet.transformX(portraitListener, -PortraitSheet.moveSpeedPx));
                    break;
                case "right":
                    portraitListener.savePortraitTransform(PortraitSheet.transformX(portraitListener, PortraitSheet.moveSpeedPx));
                    break;
                case "zoomIn":
                    portraitListener.savePortraitTransform(PortraitSheet.scale(portraitListener, PortraitSheet.zoomSpeed));
                    break;
                case "zoomOut":
                    portraitListener.savePortraitTransform(PortraitSheet.scale(portraitListener, -PortraitSheet.zoomSpeed));
                    break;
            }
        });
    }
    static getPortrait(portraitListener) {
        var _a, _b, _c;
        const info = portraitListener.getPortraitSource();
        return {
            iconScale: (_a = info.iconScale) !== null && _a !== void 0 ? _a : 1,
            iconPosY: (_b = info.iconPosY) !== null && _b !== void 0 ? _b : 0,
            iconPosX: (_c = info.iconPosX) !== null && _c !== void 0 ? _c : 0,
        };
    }
    static transformX(portraitListener, value) {
        const p = PortraitSheet.getPortrait(portraitListener);
        p.iconPosX += value;
        return p;
    }
    static transformY(portraitListener, value) {
        const p = PortraitSheet.getPortrait(portraitListener);
        p.iconPosY += value;
        return p;
    }
    static scale(portraitListener, value) {
        const p = PortraitSheet.getPortrait(portraitListener);
        p.iconScale = Math.max(0.1, p.iconScale + value);
        return p;
    }
}
PortraitSheet.moveSpeedPx = 5;
PortraitSheet.zoomSpeed = 0.1;
