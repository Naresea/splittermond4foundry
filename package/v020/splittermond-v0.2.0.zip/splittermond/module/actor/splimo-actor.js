import { DEFAULT_FERTIGKEITEN } from "../item/default-fertigkeiten.js";
import { CalculationService } from "../services/calculation-service.js";
import { GenesisImportService } from "../genesis/genesis-import-service.js";
import { GenesisExportService } from "../genesis/genesis-export-service.js";
export class SplimoActor extends Actor {
    prepareData() {
        super.prepareData();
        this.initInitiative().then(() => {
            const fertigkeiten = this.items.filter((i) => i.type === "fertigkeit" /* Fertigkeit */);
            if (fertigkeiten.length < 1) {
                this.addDefaultFertigkeiten();
            }
        });
    }
    importFromJSON(json) {
        return new Promise((resolve) => {
            const d = new Dialog({
                title: game.i18n.localize("splittermond.start-import-dialog.title"),
                content: game.i18n.localize("splittermond.start-import-dialog.content"),
                buttons: {
                    genesis: {
                        label: game.i18n.localize("splittermond.start-import-dialog.btn-genesis"),
                        callback: () => GenesisImportService.importFromGenesis(this, json),
                    },
                    default: {
                        label: game.i18n.localize("splittermond.start-import-dialog.btn-default"),
                        callback: () => super.importFromJSON(json),
                    },
                },
                default: "default",
            });
            d.render(true);
        });
    }
    exportToJSON() {
        const d = new Dialog({
            title: game.i18n.localize("splittermond.export-dialog.title"),
            content: game.i18n.localize("splittermond.export-dialog.content"),
            buttons: {
                genesis: {
                    label: game.i18n.localize("splittermond.export-dialog.btn-genesis"),
                    callback: () => GenesisExportService.exportToGenesis(this),
                },
                default: {
                    label: game.i18n.localize("splittermond.export-dialog.btn-default"),
                    callback: () => super.exportToJSON(),
                },
            },
            default: "default",
        });
        d.render(true);
    }
    async initInitiative() {
        if (this.data.data.initiativeTotal == null) {
            this.data.data.initiativeTotal = CalculationService.getInitiative(this);
            await this.update({
                id: this.id,
                data: { initiativeTotal: this.data.data.initiativeTotal },
            });
        }
    }
    async addDefaultFertigkeiten() {
        if (this.data.type === "NonPlayerCharacter") {
            this.update({
                _id: this._id,
                data: {
                    isInitialized: true,
                },
            });
            return;
        }
        const data = DEFAULT_FERTIGKEITEN.map((fertigkeit) => ({
            name: fertigkeit.name,
            type: "fertigkeit" /* Fertigkeit */,
            data: fertigkeit,
        }));
        if (!this.data.data.isInitialized) {
            const id = this._id;
            this.createEmbeddedEntity("OwnedItem", data).then(() => {
                this.update({
                    _id: id,
                    data: {
                        isInitialized: true,
                    },
                });
            });
        }
    }
}
