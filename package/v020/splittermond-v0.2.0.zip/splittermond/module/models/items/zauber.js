import { CalculationService } from "../../services/calculation-service.js";
export function buildFokusString(zauber) {
    const erschoepft = zauber.fokusErschoepft;
    const kanalisiert = zauber.fokusKanalisiert;
    const verzehrt = zauber.fokusVerzehrt;
    return CalculationService.toEKVString(erschoepft, kanalisiert, verzehrt);
}
