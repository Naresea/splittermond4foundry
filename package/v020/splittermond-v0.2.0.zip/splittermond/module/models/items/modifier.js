export var ModifierType;
(function (ModifierType) {
    ModifierType["Attribute"] = "attribute";
    ModifierType["Fertigkeit"] = "fertigkeit";
    ModifierType["TickPlus"] = "tickPlus";
    ModifierType["WoundLevels"] = "woundLevel";
})(ModifierType || (ModifierType = {}));
