export function changeInitiative(iniModifier, tokenId, actorId) {
    let combatants = [];
    const combat = game.combats.active;
    if (!combat) {
        return;
    }
    if (tokenId) {
        combatants = combat.combatants.filter((c) => c.tokenId === tokenId);
    }
    else if (actorId) {
        combatants = combat.combatants.filter((c) => c.actor._id === actorId);
    }
    else {
        const tokenIds = Object.keys(canvas.tokens._controlled);
        combatants = combat.combatants.filter((c) => tokenIds.includes(c.tokenId));
    }
    if (combatants.length < 0) {
        return;
    }
    if (combatants.length < 1) {
        if (combat.changeIniForCombatant != null) {
            combat.changeIniForCombatant(combatants[0], iniModifier);
        }
    }
    else {
        if (combat.changeIniForCombatants != null) {
            combat.changeIniForCombatants(combatants, iniModifier);
        }
    }
}
export function setupMacroHelpers() {
    var _a;
    game.splittermond = (_a = game.splittermond) !== null && _a !== void 0 ? _a : {};
    game.splittermond.macroHelpers = {
        changeInitiative: (mod) => changeInitiative(mod),
    };
}
