import { ChoiceType } from "../../models/items/chargen.js";
import { ChoiceSheet } from "./choice-sheet.js";
export class ChargenSheet {
    static getChargenData(choices) {
        const choicesForTemplate = choices.map((choice) => {
            var _a, _b;
            return ({
                fields: [
                    `splittermond.chargen.typelabels.${choice.choiceType}`,
                    `${(_a = choice.options) === null || _a === void 0 ? void 0 : _a.map((o) => game.i18n.localize(`splittermond.chargen-option-label.type.${o.type}`))}`,
                    `${(_b = choice.options) === null || _b === void 0 ? void 0 : _b.map((o) => o.name)}`,
                ],
            });
        });
        return {
            choices: choicesForTemplate,
            choicesFields: [
                "splittermond.chargen-choices.choiceType",
                "splittermond.chargen-choices.optionType",
                "splittermond.chargen-choices.optionNames",
            ],
        };
    }
    static activateChargenListeners(html, choices, updateCallback) {
        html.find(".chargen-item-edit").on("click", (evt) => {
            var _a;
            const dataset = (_a = evt === null || evt === void 0 ? void 0 : evt.currentTarget) === null || _a === void 0 ? void 0 : _a.dataset;
            if (!dataset) {
                return;
            }
            const operation = dataset["chargenOperation"];
            const index = dataset["chargenChoice"];
            if (operation === "add") {
                ChargenSheet.addChoice(choices, updateCallback);
            }
            if (operation === "edit" && Number.isNumeric(index)) {
                ChargenSheet.editChoice(choices, +index, updateCallback);
            }
            if (operation === "delete" && Number.isNumeric(index)) {
                ChargenSheet.deleteChoice(choices, +index, updateCallback);
            }
        });
    }
    static addChoice(choices, updateCallback) {
        choices.push({
            choiceType: ChoiceType.FixedValue,
            options: [],
        });
        ChargenSheet.openChoiceSheet(choices, choices.length - 1, updateCallback);
    }
    static editChoice(choices, index, updateCallback) {
        ChargenSheet.openChoiceSheet(choices, index, updateCallback);
    }
    static deleteChoice(choices, index, updateCallback) {
        choices.splice(index, 1);
        updateCallback(choices);
    }
    static openChoiceSheet(choices, index, updateCallback) {
        const choice = choices[index];
        new ChoiceSheet(choice, {}, (data) => {
            updateCallback(choices);
        }).render(true);
    }
}
