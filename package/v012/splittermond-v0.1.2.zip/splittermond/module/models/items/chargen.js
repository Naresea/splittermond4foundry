export var ChoiceType;
(function (ChoiceType) {
    /* Add [mastery | strength | weakness | feature | skill] with the given value */
    ChoiceType["FixedValue"] = "FixedValue";
    /* Add either A or B or C or... */
    ChoiceType["SelectOneOf"] = "SelectOneOf";
    /* Pick three: A, B, C, D, E, F, G... */
    ChoiceType["SelectNOf"] = "SelectNOf";
    /* Distribute x points across A, B, C, D */
    ChoiceType["DistributePoints"] = "DistributePoints";
    /* Pick one of [A,B,C] at level X and one at level Y */
    ChoiceType["MatchMultiple"] = "MatchMultiple";
})(ChoiceType || (ChoiceType = {}));
export var ChargenOptionType;
(function (ChargenOptionType) {
    ChargenOptionType["Skill"] = "fertigkeit";
    ChargenOptionType["Mastery"] = "meisterschaft";
    ChargenOptionType["Resource"] = "resource";
    ChargenOptionType["Strength"] = "staerke";
    ChargenOptionType["Weakness"] = "schwaeche";
    ChargenOptionType["Attribute"] = "attribute";
})(ChargenOptionType || (ChargenOptionType = {}));
export function isFixedValueChoice(v) {
    return v.choiceType === ChoiceType.FixedValue;
}
export function isSelectNOfChoice(v) {
    return v.choiceType === ChoiceType.SelectNOf;
}
export function isSelectOneOfChoice(v) {
    return v.choiceType === ChoiceType.SelectOneOf;
}
export function isDistributePointsChoice(v) {
    return v.choiceType === ChoiceType.DistributePoints;
}
export function isMatchMultipleChoice(v) {
    return v.choiceType === ChoiceType.MatchMultiple;
}
