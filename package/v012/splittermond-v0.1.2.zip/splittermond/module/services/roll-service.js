import { DiceRollDialog } from "../popups/dice-roll-dialog.js";
import { changeInitiative } from "../macros/setup-macro-helpers.js";
import { CalculationService } from "./calculation-service.js";
export class RollService {
    static roll(evt, actor) {
        var _a, _b, _c, _d;
        const target = evt === null || evt === void 0 ? void 0 : evt.currentTarget;
        const dataset = (_a = target) === null || _a === void 0 ? void 0 : _a.dataset;
        const rollModifier = dataset === null || dataset === void 0 ? void 0 : dataset.roll;
        const rollInfo = dataset.rollInfo
            ? JSON.parse(dataset.rollInfo)
            : undefined;
        const altKey = (_b = evt) === null || _b === void 0 ? void 0 : _b.altKey;
        const shiftKey = (_c = evt) === null || _c === void 0 ? void 0 : _c.shiftKey;
        const ctrlKey = (_d = evt) === null || _d === void 0 ? void 0 : _d.ctrlKey;
        if (rollModifier == null || !Number.isNumeric(rollModifier)) {
            return;
        }
        if (!altKey) {
            new DiceRollDialog({ rollType: "sicherheit", modifier: 0 }, {}, (data) => {
                var _a;
                const isSicherheit = data.rollType === "sicherheit";
                const isRisiko = data.rollType === "risiko";
                const extraMod = (_a = data.modifier) !== null && _a !== void 0 ? _a : 0;
                const difficulty = data.difficulty;
                RollService.doRoll(isRisiko, isSicherheit, +rollModifier + extraMod, actor, rollInfo, difficulty);
                return Promise.resolve();
            }).render(true);
        }
        else {
            RollService.doRoll(shiftKey, ctrlKey, +rollModifier, actor, rollInfo);
        }
    }
    static doRoll(isRisiko, isSicherheit, rollModifier, actor, rollInfo, difficulty) {
        const formula = isRisiko
            ? RollService.riskRoll(+rollModifier)
            : isSicherheit
                ? RollService.safeRoll(+rollModifier)
                : RollService.standardRoll(+rollModifier);
        if (rollInfo) {
            rollInfo.rollType = isSicherheit
                ? "sicherheit"
                : isRisiko
                    ? "risiko"
                    : "standard";
        }
        const roll = new Roll(formula, actor.data.data);
        const result = roll.evaluate();
        RollService.evaluateResult(result, isSicherheit, actor, rollInfo, difficulty);
    }
    static rollInitiative(evt, actor) {
        var _a;
        const target = evt === null || evt === void 0 ? void 0 : evt.currentTarget;
        const dataset = (_a = target) === null || _a === void 0 ? void 0 : _a.dataset;
        const rollModifier = dataset === null || dataset === void 0 ? void 0 : dataset.roll;
        if (rollModifier == null || !Number.isNumeric(rollModifier)) {
            return;
        }
        const formula = `${rollModifier} - 1d6`;
        const roll = new Roll(formula, actor.data.data);
        const result = roll.evaluate();
        RollService.result(result, actor);
    }
    static riskRoll(mod) {
        return `4d10kh2 + ${mod}`;
    }
    static safeRoll(mod) {
        return `2d10kh1 + ${mod}`;
    }
    static standardRoll(mod) {
        return `2d10 + ${mod}`;
    }
    static evaluateResult(roll, safe, actor, rollInfo, difficulty) {
        const dice = roll.dice;
        const values = dice[0].results.map((r) => r.result).sort((a, b) => a - b);
        rollInfo.erfolgsgrade = difficulty != null
            ? Math.sign(roll.total - difficulty) * Math.floor(Math.abs(difficulty - roll.total) / 3)
            : undefined;
        if (safe) {
            RollService.result(roll, actor, rollInfo);
            return;
        }
        if (RollService.isCritFail(values)) {
            rollInfo.erfolgsgrade = Math.min(-1, rollInfo.erfolgsgrade - 3);
            RollService.critFail(roll, actor, rollInfo);
            return;
        }
        if (RollService.isCritSuccess(values)) {
            rollInfo.erfolgsgrade = rollInfo.erfolgsgrade >= 0 ? rollInfo.erfolgsgrade + 3 : rollInfo.erfolgsgrade;
            RollService.critSuccess(roll, actor, rollInfo);
            return;
        }
        RollService.result(roll, actor, rollInfo);
    }
    static isCritFail(sortedValues) {
        return sortedValues[0] + sortedValues[1] <= 3;
    }
    static isCritSuccess(sortedValues) {
        return (sortedValues[sortedValues.length - 1] +
            sortedValues[sortedValues.length - 2] >=
            19);
    }
    static async getMessageContent(roll, actor, rollInfo, critSuccess, critFail) {
        if (!rollInfo) {
            return undefined;
        }
        const partial = Handlebars.partials["systems/splittermond/templates/sheets/roll-result.hbs"];
        const renderedRoll = await roll.render();
        const rollData = Object.assign({ roll: renderedRoll, actor,
            critSuccess,
            critFail }, rollInfo);
        return partial(rollData);
    }
    static critFail(roll, actor, rollInfo) {
        this.getMessageContent(roll, actor, rollInfo, false, true).then((content) => {
            roll.toMessage({
                speaker: ChatMessage.getSpeaker({ actor }),
                content,
            });
        });
    }
    static critSuccess(roll, actor, rollInfo) {
        this.getMessageContent(roll, actor, rollInfo, true, false).then((content) => {
            roll.toMessage({
                speaker: ChatMessage.getSpeaker({ actor }),
                content,
            });
        });
    }
    static result(roll, actor, rollInfo) {
        this.getMessageContent(roll, actor, rollInfo, false, false).then((content) => {
            roll.toMessage({
                speaker: ChatMessage.getSpeaker({ actor }),
                content,
            });
        });
    }
    static registerClickListeners(htmlElement) {
        const html = htmlElement instanceof HTMLElement ? $(htmlElement) : htmlElement;
        html.on("click", ".splittermond .tick-button", (evt) => {
            const ticks = evt.currentTarget.dataset["splimoBtnData"];
            const actorId = evt.currentTarget.dataset["splimoActorId"];
            if (Number.isNumeric(ticks) && actorId != null) {
                changeInitiative(+ticks, undefined, actorId);
            }
        });
        html.on("click", ".splittermond .damage-button", (evt) => {
            const dmg = evt.currentTarget.dataset["splimoBtnData"];
            new Roll(dmg).evaluate().toMessage();
        });
        html.on("click", ".splittermond .fokus-button", (evt) => {
            const fokus = evt.currentTarget.dataset["splimoBtnData"];
            const actorId = evt.currentTarget.dataset["splimoActorId"];
            if (fokus && actorId) {
                const { erschoepft, kanalisiert, verzehrt, } = CalculationService.fromEKVString(fokus);
                const actor = game.actors.find((a) => a.id === actorId);
                if (actor) {
                    actor.update({
                        _id: actor.id,
                        data: {
                            fokusErschoepft: actor.data.data
                                .fokusErschoepft + erschoepft,
                            fokusKanalisiert: actor.data.data
                                .fokusKanalisiert + kanalisiert,
                            fokusVerzehrt: actor.data.data
                                .fokusVerzehrt + verzehrt,
                        },
                    });
                }
            }
        });
        html.on("click", ".splittermond .tick-explanation-label", (evt) => {
            const target = evt.currentTarget instanceof HTMLElement
                ? $(evt.currentTarget)
                : evt.currentTarget;
            const text = target.find(".tick-explanation-text");
            if (text.hasClass("tick-explanation-text--active")) {
                text.removeClass("tick-explanation-text--active");
            }
            else {
                text.addClass("tick-explanation-text--active");
            }
        });
        html.on("click", ".splittermond .explanation-label", (evt) => {
            const target = evt.currentTarget instanceof HTMLElement
                ? $(evt.currentTarget)
                : evt.currentTarget;
            const text = target.find(".explanation-text");
            if (text.hasClass("explanation-text--active")) {
                text.removeClass("explanation-text--active");
            }
            else {
                text.addClass("explanation-text--active");
            }
        });
    }
}
