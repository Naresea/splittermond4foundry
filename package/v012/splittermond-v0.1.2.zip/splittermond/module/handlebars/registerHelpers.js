import { ATTRIBUTES } from "../models/actors/attributes.js";
import { DERIVED_ATTRIBUTES } from "../models/actors/derived-attributes.js";
export function registerHelpers() {
    Handlebars.registerHelper("asList", (...values) => {
        return values.filter((v) => typeof v === "string");
    });
    Handlebars.registerHelper("getByKey", (object, key, ctx) => {
        if (!object) {
            return undefined;
        }
        return object[key];
    });
    Handlebars.registerHelper("concat", (...values) => {
        return values.filter((s) => typeof s === "string").join("");
    });
    Handlebars.registerHelper("prefix", (prefix, values, ctx) => {
        const vals = values.filter((s) => typeof s === "string");
        return vals.map((v) => prefix + v);
    });
    Handlebars.registerHelper("attrNames", (options) => {
        const base = [];
        if (!options) {
            return base;
        }
        if (options.hash["base"] === true) {
            base.push(...ATTRIBUTES);
        }
        if (options.hash["derived"]) {
            base.push(...DERIVED_ATTRIBUTES);
        }
        if (options.hash["includeGK"] == null ||
            options.hash["includeGK"] === false) {
            return base.filter((v) => v !== "GK");
        }
        return base;
    });
    Handlebars.registerHelper("modifierTableHeaders", () => {
        return [
            "splittermond.modifier.type",
            "splittermond.modifier.target",
            "splittermond.modifier.value",
        ];
    });
    Handlebars.registerHelper("memeText", (color, shadowColor, width, ctx) => {
        return `
        letter-spacing: 1px;
        color: ${color};
        text-shadow: ${width} ${width} 0 ${shadowColor},
          -${width} -${width} 0 ${shadowColor},
          ${width} -${width} 0 ${shadowColor},
          -${width} ${width} 0 ${shadowColor},
          0px ${width} 0 ${shadowColor},
          ${width} 0px 0 ${shadowColor},
          0px -${width} 0 ${shadowColor},
          -${width} 0px 0 ${shadowColor},
          ${width} ${width} 5px ${shadowColor};
        `;
    });
    Handlebars.registerHelper("repeatTimes", (times, ctx) => {
        const arr = [];
        for (let i = 0; i < times; i++) {
            arr[i] = i;
        }
        return arr;
    });
    Handlebars.registerHelper("subtractClamp", (numA, numB, ctx) => {
        return Math.max(0, numA - numB);
    });
    Handlebars.registerHelper("sum", (numA, numB, ctx) => {
        return numA + numB;
    });
    Handlebars.registerHelper("clampMax", (numA, numB, ctx) => {
        return Math.min(numA, numB);
    });
    Handlebars.registerHelper("print", (options) => {
        return new Handlebars.SafeString(options.hash["content"]);
    });
    Handlebars.registerHelper("isNotNull", (val) => {
        return val !== null && val !== undefined;
    });
    Handlebars.registerHelper("simpleRollInfo", (name) => {
        return JSON.stringify({
            name,
        });
    });
    Handlebars.registerHelper("oneOf", (val, ...values) => {
        const options = Array.isArray(values[0])
            ? values[0].filter((v) => typeof v === "string" || typeof v === "number")
            : values.filter((v) => typeof v === "string" || typeof v === "number");
        return options.includes(val);
    });
}
