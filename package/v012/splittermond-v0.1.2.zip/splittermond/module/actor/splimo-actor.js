import { DEFAULT_FERTIGKEITEN } from "../item/default-fertigkeiten.js";
import { CalculationService } from "../services/calculation-service.js";
import { GenesisImportService } from "../genesis/genesis-import-service.js";
export class SplimoActor extends Actor {
    prepareData() {
        super.prepareData();
        if (this.data.data.initiativeTotal == null) {
            this.data.data.initiativeTotal = CalculationService.getInitiative(this);
            this.update({
                id: this.id,
                data: { initiativeTotal: this.data.data.initiativeTotal },
            });
        }
        const fertigkeiten = this.items.filter((i) => i.type === "fertigkeit" /* Fertigkeit */);
        if (fertigkeiten.length < 1) {
            this.addDefaultFertigkeiten();
        }
    }
    importFromJSON(json) {
        if (this.data.type === "PlayerCharacter") {
            return GenesisImportService.importFromGenesis(this, json);
        }
        else {
            return super.importFromJSON(json);
        }
    }
    exportToJSON() {
        /* if (this.data.type === 'PlayerCharacter') {
          GenesisImportService.exportToGenesis(this as Actor<PlayerCharacter>);
        } else {
          super.exportToJSON();
        }*/
        super.exportToJSON();
    }
    async addDefaultFertigkeiten() {
        const data = DEFAULT_FERTIGKEITEN.map((fertigkeit) => ({
            name: fertigkeit.name,
            type: "fertigkeit" /* Fertigkeit */,
            data: fertigkeit,
        }));
        if (!this.data.data.isInitialized) {
            const id = this._id;
            this.createEmbeddedEntity("OwnedItem", data).then(() => {
                this.update({
                    _id: id,
                    data: {
                        isInitialized: true,
                    },
                });
            });
        }
    }
}
