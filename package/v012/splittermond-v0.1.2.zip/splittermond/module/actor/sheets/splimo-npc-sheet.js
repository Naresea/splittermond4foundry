import { SplimoActorSheet } from "../splimo-actor-sheet.js";
import { CalculationService } from "../../services/calculation-service.js";
import { ModifierService } from "../../services/modifier-service.js";
import { ModifierType } from "../../models/items/modifier.js";
import { PlayerDataService } from "../../services/player-data-service.js";
import { ATTRIBUTES } from "../../models/actors/attributes.js";
import { DERIVED_ATTRIBUTES } from "../../models/actors/derived-attributes.js";
import { FertigkeitType } from "../../models/items/fertigkeit.js";
export class SplimoNpcSheet extends SplimoActorSheet {
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["splittermond"],
            template: "systems/splittermond/templates/sheets/actor/non-player-sheet.hbs",
            width: 1024,
            height: 754,
            tabs: [
                {
                    navSelector: ".sheet-tabs",
                    contentSelector: ".sheet-body",
                    initial: "attributes",
                },
                {
                    navSelector: ".fertigkeiten-tabs",
                    contentSelector: ".fertigkeiten-content",
                    initial: "allgemein",
                },
            ],
        });
    }
    getData() {
        const data = super.getData();
        const modifiers = ModifierService.getModifiers(this.actor);
        const npcData = this
            .actor.data.data;
        const maxHealth = npcData.LP *
            (5 +
                ModifierService.totalMod(modifiers, null, {
                    modType: ModifierType.WoundLevels,
                }));
        const maxFokus = npcData.FO;
        data.data.view = {
            health: {
                max: maxHealth,
                current: maxHealth -
                    npcData.healthErschoepft -
                    npcData.healthVerzehrt -
                    npcData.healthKanalisiert,
                asString: CalculationService.toEKVString(npcData.healthErschoepft, npcData.healthKanalisiert, npcData.healthVerzehrt),
            },
            fokus: {
                max: maxFokus,
                current: maxFokus -
                    npcData.fokusErschoepft -
                    npcData.fokusVerzehrt -
                    npcData.fokusKanalisiert,
                asString: CalculationService.toEKVString(npcData.fokusErschoepft, npcData.fokusKanalisiert, npcData.fokusVerzehrt),
            },
        };
        data.data.waffen = PlayerDataService.getWaffen(this.actor, modifiers);
        data.data.merkmale = PlayerDataService.getMerkmale(this.actor, modifiers);
        data.data.zustaende = PlayerDataService.getZustaende(this.actor, modifiers);
        data.data.attributeModifier = [
            ...ATTRIBUTES,
            ...DERIVED_ATTRIBUTES,
        ].reduce((accu, attr) => {
            accu[attr] = ModifierService.totalMod(modifiers, attr, {
                modType: ModifierType.Attribute,
            });
            return accu;
        }, {});
        data.data.fertigkeiten = PlayerDataService.getFertigkeitenByType(this.actor, modifiers, FertigkeitType.Allgemein);
        data.data.kampfFertigkeiten = PlayerDataService.getFertigkeitenByType(this.actor, modifiers, FertigkeitType.Kampf);
        data.data.magieFertigkeiten = PlayerDataService.getFertigkeitenByType(this.actor, modifiers, FertigkeitType.Magie);
        data.data.meisterschaften = PlayerDataService.getMeisterschaften(this.actor, modifiers);
        data.data.zauber = PlayerDataService.getZauber(this.actor, modifiers);
        return data;
    }
    _updateObject(event, formData) {
        formData = this.updateViewSpecificData(formData);
        return super._updateObject(event, formData).then(() => {
            return CalculationService.updateWoundModifier(this.actor);
        });
    }
}
