import { ModifierType } from "../models/items/modifier.js";
import { FertigkeitType } from "../models/items/fertigkeit.js";
import { CalculationService } from "../services/calculation-service.js";
const KNOWN_COMBAT_SKILL_NAMES = [
    "Handgemenge",
    "Hiebwaffen",
    "Kettenwaffen",
    "Klingenwaffen",
    "Schusswaffen",
    "Stangenwaffen",
    "Wurfwaffen",
];
const KNOWN_MAGIC_SKILL_NAMES = [
    "Bannmagie",
    "Beherrschungsmagie",
    "Bewegungsmagie",
    "Erkenntnismagie",
    "Felsmagie",
    "Feuermagie",
    "Heilungsmagie",
    "Illusionsmagie",
    "Kampfmagie",
    "Lichtmagie",
    "Naturmagie",
    "Schattenmagie",
    "Schicksalsmagie",
    "Schutzmagie",
    "Stärkungsmagie",
    "Todesmagie",
    "Verwandlungsmagie",
    "Wassermagie",
    "Windmagie",
];
export class GenesisImportService {
    static async importFromGenesis(targetActor, jsonString) {
        const genesisData = JSON.parse(jsonString);
        await GenesisImportService.importActorData(targetActor, genesisData);
        await GenesisImportService.importItemData(targetActor, genesisData);
        await CalculationService.updateWoundModifier(targetActor);
        new Dialog({
            title: game.i18n.localize("splittermond.import-dialog.title"),
            content: `<p style="padding: 10px">${game.i18n.localize("splittermond.import-dialog.content")}</p>`,
            buttons: {
                ok: {
                    icon: '<i class="fas fa-check"></i>',
                    label: "Ok",
                }
            }
        }).render(true);
        return targetActor;
    }
    static exportToGenesis(actor) {
        // TODO: implement
        // const filename = `fvtt-${actor.entity}-${actor.name.replace(/\s/g, "_")}.json`;
        // const data = GenesisImportService.mapToGenesisJson(actor);
        // saveDataToFile(JSON.stringify(data), 'text/json', filename);
    }
    static async importActorData(targetActor, genesisData) {
        const data = targetActor.data.data;
        GenesisImportService.importBiography(targetActor, genesisData);
        if (genesisData.attributes) {
            genesisData.attributes.forEach((attr) => {
                switch (attr.shortName) {
                    case "AUS":
                        data.AUS = attr.startValue;
                        data.incAUS = attr.value - attr.startValue;
                        break;
                    case "BEW":
                        data.BEW = attr.startValue;
                        data.incBEW = attr.value - attr.startValue;
                        break;
                    case "INT":
                        data.INT = attr.startValue;
                        data.incINT = attr.value - attr.startValue;
                        break;
                    case "KON":
                        data.KON = attr.startValue;
                        data.incKON = attr.value - attr.startValue;
                        break;
                    case "MYS":
                        data.MYS = attr.startValue;
                        data.incMYS = attr.value - attr.startValue;
                        break;
                    case "STÄ":
                        data.STR = attr.startValue;
                        data.incSTR = attr.value - attr.startValue;
                        break;
                    case "VER":
                        data.VER = attr.startValue;
                        data.incVER = attr.value - attr.startValue;
                        break;
                    case "WIL":
                        data.WIL = attr.startValue;
                        data.incWIL = attr.value - attr.startValue;
                        break;
                    case "SPL":
                        data.splitterpunkte.value = attr.value;
                        data.splitterpunkte.max = attr.value;
                        data.splitterpunkte.min = 0;
                        break;
                }
            });
        }
        await targetActor.update({
            _id: targetActor.id,
            name: targetActor.name,
            data: data,
        });
    }
    static importBiography(targetActor, genesisData) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
        const data = targetActor.data.data;
        targetActor.data.name = (_a = genesisData.name) !== null && _a !== void 0 ? _a : targetActor.name;
        data.geschlecht = (_b = genesisData.gender) !== null && _b !== void 0 ? _b : "";
        data.haarfarbe = (_c = genesisData.hairColor) !== null && _c !== void 0 ? _c : "";
        data.koerpergroesse = `${(_d = genesisData.size) !== null && _d !== void 0 ? _d : ""}`;
        data.augenfarbe = (_e = genesisData.eyeColor) !== null && _e !== void 0 ? _e : "";
        data.gewicht = `${(_f = genesisData.weight) !== null && _f !== void 0 ? _f : ""}`;
        data.hautfarbe = (_g = genesisData.furColor) !== null && _g !== void 0 ? _g : "";
        data.geburtsort = (_h = genesisData.birthplace) !== null && _h !== void 0 ? _h : "";
        const xpUsed = (_j = genesisData.investedExp) !== null && _j !== void 0 ? _j : 0;
        const xpFree = (_k = genesisData.freeExp) !== null && _k !== void 0 ? _k : 0;
        data.erfahrungGesamt = xpFree + xpUsed;
        data.erfahrungEingesetzt = xpUsed;
        data.heldengrad =
            xpUsed < 100 ? 1 : xpUsed < 200 ? 2 : xpUsed < 300 ? 3 : 4;
    }
    static async importItemData(targetActor, genesisData) {
        const ids = targetActor.items.map((i) => i._id);
        await targetActor.deleteEmbeddedEntity("OwnedItem", ids);
        const race = GenesisImportService.getRasse(genesisData);
        const background = GenesisImportService.getAbstammung(genesisData);
        const kultur = GenesisImportService.getKultur(genesisData);
        const ausbildung = GenesisImportService.getAusbildung(genesisData);
        const fertigkeiten = GenesisImportService.getFertigkeiten(genesisData);
        const meisterschaften = GenesisImportService.getMeisterschaften(genesisData);
        const schwaechen = GenesisImportService.getSchwaechen(genesisData);
        const staerken = GenesisImportService.getStaerken(genesisData);
        const resourcen = GenesisImportService.getResourcen(genesisData);
        const zauber = GenesisImportService.getZauber(genesisData);
        const gegenstaende = GenesisImportService.getItems(genesisData);
        const waffen = GenesisImportService.getWaffen(genesisData);
        const schilde = GenesisImportService.getSchilde(genesisData);
        const ruestungen = GenesisImportService.getRuestungen(genesisData);
        const mondzeichen = GenesisImportService.getMondzeichen(genesisData);
        await targetActor.createOwnedItem([
            race,
            background,
            kultur,
            ausbildung,
            ...fertigkeiten,
            ...meisterschaften,
            ...schwaechen,
            ...staerken,
            ...resourcen,
            ...zauber,
            ...gegenstaende,
            ...waffen,
            ...schilde,
            ...ruestungen,
            mondzeichen,
        ]);
    }
    static getRasse(genesisData) {
        var _a, _b, _c;
        const raceName = (_a = genesisData.race) !== null && _a !== void 0 ? _a : "";
        const gk = (_c = (_b = genesisData.attributes.find((a) => a.shortName === "GK")) === null || _b === void 0 ? void 0 : _b.value) !== null && _c !== void 0 ? _c : 0;
        return {
            name: raceName,
            type: "rasse" /* Rasse */,
            data: {
                modifier: [{ type: ModifierType.Attribute, target: "GK", value: gk }],
            },
        };
    }
    static getAbstammung(genesisData) {
        var _a;
        const name = (_a = genesisData.background) !== null && _a !== void 0 ? _a : "";
        return {
            name,
            type: "abstammung" /* Abstammung */,
            data: {},
        };
    }
    static getKultur(genesisData) {
        var _a, _b, _c;
        const name = (_a = genesisData.culture) !== null && _a !== void 0 ? _a : "";
        const lore = ((_b = genesisData.cultureLores) !== null && _b !== void 0 ? _b : []).join(", ");
        const language = ((_c = genesisData.languages) !== null && _c !== void 0 ? _c : []).join(", ");
        return {
            name,
            type: "kultur" /* Kultur */,
            data: {
                sprache: language,
                kulturkunde: lore,
            },
        };
    }
    static getAusbildung(genesisData) {
        const name = genesisData.education;
        return {
            name,
            type: "ausbildung" /* Ausbildung */,
            data: {},
        };
    }
    static getFertigkeiten(genesisData) {
        if (!genesisData.skills) {
            return [];
        }
        return genesisData.skills.map((skill, idx) => {
            var _a, _b;
            return ({
                name: (_a = skill.name) !== null && _a !== void 0 ? _a : `Unnamed Skill ${idx}`,
                type: "fertigkeit" /* Fertigkeit */,
                data: {
                    punkte: (_b = skill.points) !== null && _b !== void 0 ? _b : 0,
                    // do not import modifier: it will be applied automatically when the corresponding gear is equipped
                    attributEins: GenesisImportService.getAttributeShortname(skill.attribute1),
                    attributZwei: GenesisImportService.getAttributeShortname(skill.attribute2),
                    type: KNOWN_COMBAT_SKILL_NAMES.includes(skill.name)
                        ? FertigkeitType.Kampf
                        : KNOWN_MAGIC_SKILL_NAMES.includes(skill.name)
                            ? FertigkeitType.Magie
                            : FertigkeitType.Allgemein,
                },
            });
        });
    }
    static getAttributeShortname(name) {
        if (!name) {
            return "";
        }
        switch (name) {
            case "STÄ":
                return "STR";
            default:
                return name;
        }
    }
    static getMeisterschaften(genesisData) {
        if (!genesisData.skills) {
            return [];
        }
        return genesisData.skills
            .map((skill, idx) => skill.masterships.map((mastery) => {
            var _a, _b, _c, _d, _e, _f;
            return ({
                name: (_a = mastery.name) !== null && _a !== void 0 ? _a : "",
                type: "meisterschaft" /* Meisterschaft */,
                data: {
                    schwelle: (_b = mastery.level) !== null && _b !== void 0 ? _b : 0,
                    fertigkeit: (_c = skill.name) !== null && _c !== void 0 ? _c : `Unnamed Skill ${idx}`,
                    beschreibung: `<p>${(_d = mastery.shortDescription) !== null && _d !== void 0 ? _d : ""}</p><p>${(_e = mastery.longDescription) !== null && _e !== void 0 ? _e : ""}</p>`,
                    regelwerk: (_f = mastery.page) !== null && _f !== void 0 ? _f : "",
                },
            });
        }))
            .reduce((accu, curr) => {
            accu.push(...curr);
            return accu;
        }, []);
    }
    static getStaerken(genesisData) {
        if (!genesisData.powers) {
            return [];
        }
        return genesisData.powers.map((power, idx) => {
            var _a, _b, _c, _d;
            return ({
                name: (_a = power.name) !== null && _a !== void 0 ? _a : `Unnamed Strength ${idx}`,
                type: "staerke" /* Staerke */,
                data: {
                    beschreibung: `<p>${(_b = power.shortDescription) !== null && _b !== void 0 ? _b : ""}</p><p>${(_c = power.longDescription) !== null && _c !== void 0 ? _c : ""}</p>`,
                    regelwerk: (_d = power.page) !== null && _d !== void 0 ? _d : "",
                    level: power.count,
                },
            });
        });
    }
    static getSchwaechen(genesisData) {
        if (!genesisData.weaknesses) {
            return [];
        }
        return genesisData.weaknesses.map((w) => ({
            name: w,
            type: "schwaeche" /* Schwaeche */,
            data: {},
        }));
    }
    static getResourcen(genesisData) {
        if (!genesisData.resources) {
            return [];
        }
        return genesisData.resources.map((res, idx) => {
            var _a, _b, _c;
            return ({
                name: (_a = res.name) !== null && _a !== void 0 ? _a : `Unnamed Resource ${idx}`,
                type: "resource" /* Resource */,
                data: {
                    beschreibung: `<p>${(_b = res.description) !== null && _b !== void 0 ? _b : ""}</p>`,
                    punkte: (_c = res.value) !== null && _c !== void 0 ? _c : 0,
                },
            });
        });
    }
    static getZauber(genesisData) {
        if (!genesisData.spells) {
            return [];
        }
        return genesisData.spells.map((spell, idx) => {
            var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
            const { erschoepft, verzehrt, kanalisiert, } = CalculationService.fromEKVString((_a = spell.focus) !== null && _a !== void 0 ? _a : "0");
            return {
                name: (_b = spell.name) !== null && _b !== void 0 ? _b : `Unnamed Spell ${idx}`,
                type: "zauber" /* Zauber */,
                data: {
                    grad: (_c = spell.schoolGrade) !== null && _c !== void 0 ? _c : 0,
                    fertigkeit: (_d = spell.school) !== null && _d !== void 0 ? _d : "",
                    schwierigkeitString: (_e = spell.difficulty) !== null && _e !== void 0 ? _e : "0",
                    fokusErschoepft: erschoepft,
                    fokusVerzehrt: verzehrt,
                    fokusKanalisiert: kanalisiert,
                    zauberdauerString: (_f = spell.castDuration) !== null && _f !== void 0 ? _f : "",
                    reichweiteString: (_g = spell.castRange) !== null && _g !== void 0 ? _g : "",
                    wirkungsdauerString: (_h = spell.spellDuration) !== null && _h !== void 0 ? _h : "",
                    bereichString: "",
                    verstaerkung: (_j = spell.enhancement) !== null && _j !== void 0 ? _j : "",
                    beschreibung: `<p>${spell.longDescription}</p>`,
                    regelwerk: (_k = spell.page) !== null && _k !== void 0 ? _k : "",
                    schaden: "",
                },
            };
        });
    }
    static getItems(genesisData) {
        if (!genesisData.items) {
            return [];
        }
        return genesisData.items.map((item, idx) => {
            var _a;
            return ({
                name: (_a = item.name) !== null && _a !== void 0 ? _a : `Unnamed Item ${idx}`,
                type: "gegenstand" /* Gegenstand */,
                data: {
                    wertInTellaren: 0,
                    gewicht: 0,
                    anzahl: item.count,
                },
            });
        });
    }
    static getMerkmalString(feature) {
        if (feature.level < 1 || feature.name.match(/\d+$/)) {
            // level included in name
            return `${feature.name}`;
        }
        return `${feature.name} ${feature.level}`;
    }
    static getWaffen(genesisData) {
        var _a, _b;
        const weapons = [
            ...((_a = genesisData.meleeWeapons) !== null && _a !== void 0 ? _a : []),
            ...((_b = genesisData.longRangeWeapons) !== null && _b !== void 0 ? _b : []),
        ];
        return weapons.map((weapon, idx) => {
            var _a, _b, _c, _d, _e, _f, _g;
            return ({
                name: (_a = weapon.name) !== null && _a !== void 0 ? _a : `Unnamed Weapon ${idx}`,
                type: "waffe" /* Waffe */,
                data: {
                    attribute: GenesisImportService.getAttributeShortname(weapon.attribute1),
                    attributeSecondary: GenesisImportService.getAttributeShortname(weapon.attribute2),
                    fertigkeit: (_b = weapon.skill) !== null && _b !== void 0 ? _b : "",
                    schaden: (_c = weapon.damage.replace(/W/g, "D")) !== null && _c !== void 0 ? _c : "",
                    ticks: (_d = weapon.weaponSpeed) !== null && _d !== void 0 ? _d : 0,
                    merkmale: ((_e = weapon === null || weapon === void 0 ? void 0 : weapon.features) !== null && _e !== void 0 ? _e : [])
                        .map(GenesisImportService.getMerkmalString)
                        .join(", "),
                    reichweite: (_g = (_f = weapon) === null || _f === void 0 ? void 0 : _f.range) !== null && _g !== void 0 ? _g : 0,
                    isEquipped: idx === 0,
                },
            });
        });
    }
    static getSchilde(genesisData) {
        if (!genesisData.shields) {
            return [];
        }
        return genesisData.shields.map((shield, idx) => {
            var _a, _b, _c, _d;
            return ({
                name: (_a = shield.name) !== null && _a !== void 0 ? _a : `Unnamed Shield ${idx}`,
                type: "schild" /* Schild */,
                data: {
                    VTD: shield.defensePlus,
                    BEH: shield.handicap,
                    schaden: (_b = shield.damage.replace(/W/g, "D")) !== null && _b !== void 0 ? _b : "",
                    fertigkeit: (_c = shield.skill) !== null && _c !== void 0 ? _c : "",
                    attribute: "INT",
                    attributeSecondary: "STR",
                    merkmale: ((_d = shield === null || shield === void 0 ? void 0 : shield.features) !== null && _d !== void 0 ? _d : [])
                        .map(GenesisImportService.getMerkmalString)
                        .join(", "),
                    isEquipped: idx === 0,
                },
            });
        });
    }
    static getRuestungen(genesisData) {
        if (!genesisData.armors) {
            return [];
        }
        return genesisData.armors.map((armor, idx) => {
            var _a, _b, _c;
            return ({
                name: (_a = armor.name) !== null && _a !== void 0 ? _a : `Unnamed Armor ${idx}`,
                type: "ruestung" /* Ruestung */,
                data: {
                    VTD: armor.defense,
                    SR: armor.damageReduction,
                    BEH: armor.handicap,
                    tickPlus: (_b = armor.tickMalus) !== null && _b !== void 0 ? _b : 0,
                    merkmale: ((_c = armor === null || armor === void 0 ? void 0 : armor.features) !== null && _c !== void 0 ? _c : [])
                        .map(GenesisImportService.getMerkmalString)
                        .join(", "),
                    isEquipped: idx === 0,
                },
            });
        });
    }
    static getMondzeichen(genesisData) {
        if (!genesisData.moonSign) {
            return {
                name: `No moonsign`,
                type: "mondzeichen" /* Mondzeichen */,
                data: {},
            };
        }
        return {
            name: genesisData.moonSign.name,
            type: "mondzeichen" /* Mondzeichen */,
            data: {
                beschreibung: `<p>${genesisData.moonSign.description}</p>`,
            },
        };
    }
    static mapToGenesisJson(actor) {
        // TODO: implement
        return undefined;
    }
}
