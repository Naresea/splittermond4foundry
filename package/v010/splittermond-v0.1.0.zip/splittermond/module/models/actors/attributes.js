export const ATTRIBUTES = [
    "AUS",
    "BEW",
    "INT",
    "KON",
    "MYS",
    "STR",
    "VER",
    "WIL",
    "GK",
];
