export const DERIVED_ATTRIBUTES = [
    "GSW",
    "INI",
    "LP",
    "FO",
    "VTD",
    "GW",
    "KW",
];
