export class SplimoItemSheet extends ItemSheet {
    activateListeners(html) {
        super.activateListeners(html);
        // ignore: TS types not yet available
        // @ts-ignore
        const dragDrop = new DragDrop({
            dragSelector: ".item",
            dropSelector: ".items",
            permissions: {
                dragstart: this._canDragStart.bind(this),
                drop: this._canDragDrop.bind(this),
            },
            callbacks: {
                dragstart: this._onDragStart.bind(this),
                drop: this._onDragDrop.bind(this),
            },
        });
        const htmlElement = html.get()[0];
        console.log("Binding drag&drop to HTML: ", { htmlElement });
        // @ts-ignore
        dragDrop.bind(htmlElement);
    }
    _canDragStart(selector) {
        console.log("Can Drag start: ", selector);
        return true;
    }
    _canDragDrop(selector) {
        console.log("Can drag drop: ", selector);
        return true;
    }
    _onDragStart(event) {
        console.log("OnDragStart: ", event);
        super._onDragStart(event);
    }
    _onDragDrop(event) {
        console.log("OnDragDrop:", event);
    }
}
