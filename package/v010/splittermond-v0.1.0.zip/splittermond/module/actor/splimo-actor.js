import { DEFAULT_FERTIGKEITEN } from "../item/default-fertigkeiten.js";
import { CalculationService } from "../services/calculation-service.js";
export class SplimoActor extends Actor {
    prepareData() {
        super.prepareData();
        if (this.data.data.initiativeTotal == null) {
            this.data.data.initiativeTotal = CalculationService.getInitiative(this);
            this.update({
                id: this.id,
                data: { initiativeTotal: this.data.data.initiativeTotal },
            });
        }
        const fertigkeiten = this.items.filter((item) => item.type === "fertigkeit" /* Fertigkeit */);
        if (fertigkeiten.length < 1) {
            this.addDefaultFertigkeiten();
        }
    }
    addDefaultFertigkeiten() {
        const data = DEFAULT_FERTIGKEITEN.map((fertigkeit) => ({
            name: fertigkeit.name,
            type: "fertigkeit" /* Fertigkeit */,
            data: fertigkeit,
        }));
        this.createEmbeddedEntity("OwnedItem", data);
    }
}
