import { SplimoItemSheet } from "../splimo-item-sheet.js";
export class BenutzbarSheet extends SplimoItemSheet {
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["splittermond"],
            template: "systems/splittermond/templates/sheets/item/benutzbar-sheet.hbs",
            width: 512,
            height: 766,
            tabs: [
                {
                    navSelector: ".sheet-tabs",
                    contentSelector: ".sheet-body",
                    initial: "usable",
                },
            ],
        });
    }
    getData() {
        const data = super.getData();
        console.log("Get data usabale: ", data);
        return data;
    }
    _updateObject(event, formData) {
        console.log("Updating usable: ", formData);
        return super._updateObject(event, formData);
    }
}
