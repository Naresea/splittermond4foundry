import { SplimoItem } from "./splimo-item.js";
import { AbstammungSheet } from "./sheets/abstammung-sheet.js";
import { AusbildungSheet } from "./sheets/ausbildung-sheet.js";
import { KulturSheet } from "./sheets/kultur-sheet.js";
import { RasseSheet } from "./sheets/rasse-sheet.js";
import { MondzeichenSheet } from "./sheets/mondzeichen-sheet.js";
import { StaerkeSheet } from "./sheets/staerke-sheet.js";
import { SchwaecheSheet } from "./sheets/schwaeche-sheet.js";
import { FertigkeitSheet } from "./sheets/fertigkeit-sheet.js";
import { MeisterschaftSheet } from "./sheets/meisterschaft-sheet.js";
import { ResourceSheet } from "./sheets/resource-sheet.js";
import { ZauberSheet } from "./sheets/zauber-sheet.js";
import { WaffeSheet } from "./sheets/waffe-sheet.js";
import { RuestungSheet } from "./sheets/ruestung-sheet.js";
import { SchildSheet } from "./sheets/schild-sheet.js";
import { GegenstandSheet } from "./sheets/gegenstand-sheet.js";
import { BenutzbarSheet } from "./sheets/benutzbar-sheet.js";
import { MerkmalSheet } from "./sheets/merkmal-sheet.js";
import { ZustandSheet } from "./sheets/zustand-sheet.js";
export function registerItemSheets() {
    CONFIG.Item.entityClass = SplimoItem;
    Items.unregisterSheet("core", ItemSheet);
    Items.registerSheet("splittermond", AbstammungSheet, {
        types: ["abstammung" /* Abstammung */],
        makeDefault: true,
    });
    Items.registerSheet("splittermond", AusbildungSheet, {
        types: ["ausbildung" /* Ausbildung */],
        makeDefault: true,
    });
    Items.registerSheet("splittermond", KulturSheet, {
        types: ["kultur" /* Kultur */],
        makeDefault: true,
    });
    Items.registerSheet("splittermond", RasseSheet, {
        types: ["rasse" /* Rasse */],
        makeDefault: true,
    });
    Items.registerSheet("splittermond", MondzeichenSheet, {
        types: ["mondzeichen" /* Mondzeichen */],
        makeDefault: true,
    });
    Items.registerSheet("splittermond", StaerkeSheet, {
        types: ["staerke" /* Staerke */],
        makeDefault: true,
    });
    Items.registerSheet("splittermond", SchwaecheSheet, {
        types: ["schwaeche" /* Schwaeche */],
        makeDefault: true,
    });
    Items.registerSheet("splittermond", FertigkeitSheet, {
        types: ["fertigkeit" /* Fertigkeit */],
        makeDefault: true,
    });
    Items.registerSheet("splittermond", MeisterschaftSheet, {
        types: ["meisterschaft" /* Meisterschaft */],
        makeDefault: true,
    });
    Items.registerSheet("splittermond", ResourceSheet, {
        types: ["resource" /* Resource */],
        makeDefault: true,
    });
    Items.registerSheet("splittermond", ZauberSheet, {
        types: ["zauber" /* Zauber */],
        makeDefault: true,
    });
    Items.registerSheet("splittermond", WaffeSheet, {
        types: ["waffe" /* Waffe */],
        makeDefault: true,
    });
    Items.registerSheet("splittermond", RuestungSheet, {
        types: ["ruestung" /* Ruestung */],
        makeDefault: true,
    });
    Items.registerSheet("splittermond", SchildSheet, {
        types: ["schild" /* Schild */],
        makeDefault: true,
    });
    Items.registerSheet("splittermond", GegenstandSheet, {
        types: ["gegenstand" /* Gegenstand */],
        makeDefault: true,
    });
    Items.registerSheet("splittermond", BenutzbarSheet, {
        types: ["benutzbar" /* Benutzbar */],
        makeDefault: true,
    });
    Items.registerSheet("splittermond", MerkmalSheet, {
        types: ["merkmal" /* Merkmal */],
        makeDefault: true,
    });
    Items.registerSheet("splittermond", ZustandSheet, {
        types: ["zustand" /* Zustand */],
        makeDefault: true,
    });
}
export function getSheetClass(type) {
    switch (type) {
        case "abstammung" /* Abstammung */:
            return AbstammungSheet;
        case "ausbildung" /* Ausbildung */:
            return AusbildungSheet;
        case "kultur" /* Kultur */:
            return KulturSheet;
        case "rasse" /* Rasse */:
            return RasseSheet;
        case "mondzeichen" /* Mondzeichen */:
            return MondzeichenSheet;
        case "staerke" /* Staerke */:
            return StaerkeSheet;
        case "schwaeche" /* Schwaeche */:
            return SchwaecheSheet;
        case "fertigkeit" /* Fertigkeit */:
            return FertigkeitSheet;
        case "meisterschaft" /* Meisterschaft */:
            return MeisterschaftSheet;
        case "resource" /* Resource */:
            return ResourceSheet;
        case "zauber" /* Zauber */:
            return ZauberSheet;
        case "waffe" /* Waffe */:
            return WaffeSheet;
        case "ruestung" /* Ruestung */:
            return RuestungSheet;
        case "schild" /* Schild */:
            return SchildSheet;
        case "gegenstand" /* Gegenstand */:
            return GegenstandSheet;
        case "benutzbar" /* Benutzbar */:
            return BenutzbarSheet;
        case "merkmal" /* Merkmal */:
            return MerkmalSheet;
        case "zustand" /* Zustand */:
            return ZustandSheet;
        default:
            return undefined;
    }
}
