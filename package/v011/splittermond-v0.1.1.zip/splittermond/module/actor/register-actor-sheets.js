import { SplimoActor } from "./splimo-actor.js";
import { SplimoPlayerSheet } from "./sheets/splimo-player-sheet.js";
import { SplimoNpcSheet } from "./sheets/splimo-npc-sheet.js";
export function registerActorSheets() {
    CONFIG.Actor.entityClass = SplimoActor;
    Actors.unregisterSheet("core", ActorSheet);
    Actors.registerSheet("splittermond", SplimoPlayerSheet, {
        types: ["PlayerCharacter" /* PlayerCharacter */],
        makeDefault: true,
    });
    Actors.registerSheet("splittermond", SplimoNpcSheet, {
        types: ["NonPlayerCharacter" /* NonPlayerCharacter */],
        makeDefault: false,
    });
}
