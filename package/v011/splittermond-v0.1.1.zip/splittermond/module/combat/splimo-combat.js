import { TickDialog } from "../popups/tick-dialog.js";
import { ModifierService } from "../services/modifier-service.js";
import { ModifierType } from "../models/items/modifier.js";
export class SplimoCombat extends Combat {
    _sortCombatants(a, b) {
        var _a, _b;
        const ia = Number.isNumeric(a.initiative) ? a.initiative : -9999;
        const ib = Number.isNumeric(b.initiative) ? b.initiative : -9999;
        let ci = ia - ib;
        if (ci !== 0)
            return ci;
        let [an, bn] = [((_a = a.token) === null || _a === void 0 ? void 0 : _a.name) || "", ((_b = b.token) === null || _b === void 0 ? void 0 : _b.name) || ""];
        let cn = an.localeCompare(bn);
        if (cn !== 0)
            return cn;
        return a.tokenId - b.tokenId;
    }
    //@ts-ignore
    get turn() {
        return 0;
    }
    //@ts-ignore
    get round() {
        return 0;
    }
    async nextRound() {
        return this.changeIni();
    }
    async nextTurn() {
        return;
    }
    async previousRound() {
        return;
    }
    async previousTurn() {
        return;
    }
    async changeIni() {
        const combatant = this.combatants.sort((a, b) => this._sortCombatants(a, b))[0];
        if (!combatant) {
            console.warn("Next round requested, but no combatants exist!");
            return;
        }
        return this.changeIniForCombatant(combatant);
    }
    async changeIniForCombatant(combatant, iniModifier) {
        if (iniModifier != null) {
            this.setInitiative(combatant._id, combatant.initiative + iniModifier);
            return;
        }
        const mods = ModifierService.getModifiers(combatant.actor);
        const tickPlus = ModifierService.totalMod(mods, null, {
            modType: ModifierType.TickPlus,
        });
        return new Promise((resolve) => {
            new TickDialog({
                tickPlus: tickPlus !== null && tickPlus !== void 0 ? tickPlus : 0,
                modifier: 0,
            }, {}, (data) => {
                if (data != null) {
                    this.setInitiative(combatant._id, combatant.initiative + data.modifier);
                }
                resolve();
            }).render(true);
        });
    }
    async changeIniForCombatants(combatant, iniModifier) {
        if (iniModifier != null) {
            combatant.forEach((c) => {
                this.setInitiative(c._id, c.initiative + iniModifier);
            });
            return;
        }
        return new Promise((resolve) => {
            new TickDialog({
                tickPlus: 0,
                modifier: 0,
            }, {}, (data) => {
                if (data != null) {
                    combatant.forEach((c) => {
                        this.setInitiative(c._id, c.initiative + data.modifier);
                    });
                }
                resolve();
            }).render(true);
        });
    }
}
