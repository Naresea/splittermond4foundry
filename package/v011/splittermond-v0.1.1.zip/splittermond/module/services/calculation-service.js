import { ModifierService } from "./modifier-service.js";
import { ModifierType } from "../models/items/modifier.js";
import { PlayerDataService } from "./player-data-service.js";
export class CalculationService {
    static getInitiative(actor) {
        var _a;
        if (actor.data.type === "PlayerCharacter" /* PlayerCharacter */) {
            const data = PlayerDataService.getPlayerData(actor);
            return data.derivedAttributes.INI.total;
        }
        else {
            const modifiers = ModifierService.getModifiers(actor);
            const iniMod = ModifierService.totalMod(modifiers, "INI", {
                modType: ModifierType.Attribute,
            });
            return ((_a = actor.data.data.INI) !== null && _a !== void 0 ? _a : 0) + iniMod;
        }
    }
    static getAttributeValue(actor, attribute, mods) {
        var _a, _b, _c;
        const startValue = (_a = actor.data.data[attribute]) !== null && _a !== void 0 ? _a : 0;
        const increasedValue = (_b = actor.data.data["inc" + attribute]) !== null && _b !== void 0 ? _b : 0;
        const modifierValue = (_c = ModifierService.totalMod(mods, attribute, {
            modType: ModifierType.Attribute,
        })) !== null && _c !== void 0 ? _c : 0;
        const total = startValue + increasedValue + modifierValue;
        return {
            total,
            explanation: `Start ${startValue} + Erhöht ${increasedValue} + Mod ${modifierValue}`,
        };
    }
    static getFertigkeitsValue(actor, fertigkeit, mods) {
        const fertigkeitItem = actor.items.find((item) => item.type === "fertigkeit" /* Fertigkeit */ && item.name === fertigkeit);
        if (!fertigkeitItem) {
            return {
                total: 0,
                explanation: "Keine Fertigkeit",
            };
        }
        const attrEins = CalculationService.getAttributeValue(actor, fertigkeitItem.data.data.attributEins, mods).total;
        const attrZwei = CalculationService.getAttributeValue(actor, fertigkeitItem.data.data.attributZwei, mods).total;
        const mod = ModifierService.totalMod(mods, fertigkeit, {
            modType: ModifierType.Fertigkeit,
        });
        const total = attrEins +
            attrZwei +
            mod +
            fertigkeitItem.data.data.punkte +
            fertigkeitItem.data.data.mod;
        return {
            total,
            explanation: `${fertigkeitItem.data.data.attributEins} ${attrEins} + ${fertigkeitItem.data.data.attributZwei} ${attrZwei} + ${fertigkeitItem.name} ${fertigkeitItem.data.data.punkte} + Mod ${fertigkeitItem.data.data.mod}`,
        };
    }
    static getWaffeOrSchildValue(actor, waffe, mods, name) {
        const fertigkeitItem = actor.items.find((item) => item.type === "fertigkeit" /* Fertigkeit */ && item.name === waffe.fertigkeit);
        const attrEins = CalculationService.getAttributeValue(actor, waffe.attribute, mods).total;
        const attrZwei = CalculationService.getAttributeValue(actor, waffe.attributeSecondary, mods).total;
        let total = attrEins + attrZwei + waffe.mod;
        let explanation = `Waffe ${name ? `(${name})` : ""} ${waffe.mod} + ${waffe.attribute} ${attrEins} + ${waffe.attributeSecondary} ${attrZwei}`;
        if (!fertigkeitItem) {
            return {
                total,
                explanation,
            };
        }
        const fertigkeitVal = fertigkeitItem.data.data.punkte + fertigkeitItem.data.data.mod;
        const fertigkeitMod = ModifierService.totalMod(mods, fertigkeitItem.name, {
            modType: ModifierType.Fertigkeit,
        });
        explanation += ` + ${waffe.fertigkeit} ${fertigkeitVal + fertigkeitMod}`;
        total += fertigkeitVal + fertigkeitMod;
        return {
            total,
            explanation,
        };
    }
    static fromEKVString(ekvString) {
        const kanalisiertMatch = ekvString.match(/[Kk]\d+/);
        const kanalisiert = kanalisiertMatch
            ? +kanalisiertMatch[0].replace(/[Kk]/, "")
            : 0;
        const verzehrtMatch = ekvString.match(/[Vv]\d+/);
        const verzehrt = verzehrtMatch ? +verzehrtMatch[0].replace(/[Vv]/, "") : 0;
        const erschoepftMatch = ekvString.match(/\d+/);
        const erschoepft = erschoepftMatch ? +erschoepftMatch[0] : 0;
        return {
            erschoepft,
            kanalisiert,
            verzehrt,
        };
    }
    static toEKVString(erschoepft, kanalisiert, verzehrt) {
        return `${erschoepft}K${kanalisiert}V${verzehrt}`;
    }
}
