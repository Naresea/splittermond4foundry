export class ChargenSelectOne extends FormApplication {
    constructor(object, options, submit) {
        super(object, options);
        this.submitCallback = submit;
    }
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["splittermond"],
            template: "systems/splittermond/templates/sheets/popups/chargen-select-one.hbs",
            width: 512,
            height: 340,
            submitOnChange: false,
            submitOnClose: false,
            closeOnSubmit: true,
            editable: true,
        });
    }
    getData(options) {
        return {
            labels: this.object.options.map((opt) => `${game.i18n.localize(`splittermond.chargen-option-label.type.${opt.type}`)} ${opt.name}${opt.points ? ` (${opt.points})` : ""}`),
            values: this.object.options.map((opt) => opt.name),
        };
    }
    activateListeners(html) {
        super.activateListeners(html);
        if (html instanceof HTMLElement) {
            console.error("ChargenSelectOne: html is of wrong type.");
            return;
        }
        html.find(".btn-submit").on("click", (evt) => {
            var _a, _b;
            const select = html.find('select[name="selectedOption"]').get()[0];
            const selectedIndex = (_b = +((_a = select) === null || _a === void 0 ? void 0 : _a.selectedIndex)) !== null && _b !== void 0 ? _b : 0;
            const option = this.object.options[selectedIndex];
            if (this.submitCallback) {
                this.submitCallback(option);
            }
            this.close();
        });
    }
    _updateObject(event, formData) {
        return Promise.resolve();
    }
}
