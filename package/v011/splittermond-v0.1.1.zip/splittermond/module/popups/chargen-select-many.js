export class ChargenSelectMany extends FormApplication {
    constructor(object, options, submit) {
        super(object, options);
        this.selectedIndices = [];
        this.submitCallback = submit;
    }
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["splittermond"],
            template: "systems/splittermond/templates/sheets/popups/chargen-select-many.hbs",
            width: 512,
            height: 512,
            submitOnChange: true,
            submitOnClose: true,
            closeOnSubmit: false,
            editable: true,
        });
    }
    getData(opt) {
        const options = this.object.options.map((opt, idx) => (Object.assign(Object.assign({}, opt), { label: `${game.i18n.localize(`splittermond.chargen-option-label.type.${opt.type}`)} ${opt.name}${opt.points ? ` (${opt.points})` : ""}`, index: idx })));
        const remaining = this.object.numN - this.selectedIndices.length;
        return {
            options,
            selectedIndices: this.selectedIndices,
            numN: this.object.numN,
            remaining: remaining,
            canSubmit: remaining === 0,
        };
    }
    activateListeners(html) {
        super.activateListeners(html);
        if (html instanceof HTMLElement) {
            console.error("ChargenSelectMany: html is of wrong type.");
            return;
        }
        html.find(".btn-submit").on("click", (evt) => {
            const select = html.find('select[name="selectedOption"]').get()[0];
            const selectedOptions = this.object.options.filter((o, idx) => this.selectedIndices.includes(idx));
            if (this.submitCallback) {
                console.log("Calling submit callback with ", selectedOptions);
                this.submitCallback(selectedOptions);
            }
            this.close();
        });
    }
    _updateObject(event, formData) {
        this.selectedIndices = [];
        for (let i = 0; i < this.object.options.length; i++) {
            const data = formData[`option.${i}`];
            if (data === true) {
                this.selectedIndices.push(i);
            }
        }
        this.render();
        return Promise.resolve();
    }
}
