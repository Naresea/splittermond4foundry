import { RollService } from "../services/roll-service.js";
import { getSheetClass } from "../item/register-item-sheets.js";
import { CalculationService } from "../services/calculation-service.js";
import { ChargenService } from "../services/chargen-service.js";
import { PlayerDataService } from "../services/player-data-service.js";
import { PortraitSheet } from "./sheets/portrait-sheet.js";
export class SplimoActorSheet extends ActorSheet {
    getPortraitSource() {
        return this.actor.data.data;
    }
    savePortraitTransform(port) {
        this.actor.update({
            _id: this.actor._id,
            data: Object.assign({}, port),
        });
    }
    activateListeners(html) {
        super.activateListeners(html);
        if (html instanceof HTMLElement) {
            console.error("activateListeners: html is wrong element, should be JQuery but is HTMLElement");
            return;
        }
        this.registerClick(html);
        PortraitSheet.activatePortraitListener(html, this);
    }
    get title() {
        const woundModifier = PlayerDataService.getWoundModifier(this.actor);
        return `${super.title}${woundModifier
            ? ` ( ${woundModifier.name}: ${woundModifier.modifier} )`
            : ""}`;
    }
    _onDrop(event) {
        var _a, _b;
        const dataTransfer = (_b = (_a = event) === null || _a === void 0 ? void 0 : _a.dataTransfer) === null || _b === void 0 ? void 0 : _b.getData("text/plain");
        if (dataTransfer) {
            const { type, id } = JSON.parse(dataTransfer);
            if (type === "Item") {
                const item = game.items.get(id);
                if (item &&
                    ChargenService.CHARGEN_ITEM_TYPES.includes(item.type)) {
                    ChargenService.applyChargenData(this.actor, item);
                }
            }
        }
        return super._onDrop(event);
    }
    registerClick(html) {
        html.on("click", `.clickable`, (evt) => {
            var _a, _b, _c;
            const target = evt === null || evt === void 0 ? void 0 : evt.target;
            const operation = (_a = target === null || target === void 0 ? void 0 : target.dataset) === null || _a === void 0 ? void 0 : _a.operation;
            const type = (_b = target === null || target === void 0 ? void 0 : target.dataset) === null || _b === void 0 ? void 0 : _b.type;
            const id = target === null || target === void 0 ? void 0 : target.dataset["clickId"];
            if (operation === "add" && type != null) {
                this.createItem(type);
            }
            if (operation === "edit" && type != null) {
                this.editItem(type, id);
            }
            if (operation === "delete" && type != null) {
                this.deleteItem(type, id);
            }
            if (operation === "equip") {
                this.equipItem(type, id);
            }
            if (operation === "unequip") {
                this.unequipItem(type, id);
            }
            if (operation === "sp-add") {
                this.addSplitterpunkt();
            }
            if (operation === "sp-reduce") {
                this.removeSplitterpunkt();
            }
            if (operation === "roll") {
                RollService.roll(evt, this.actor);
            }
            if (operation === "iniRoll") {
                if (game.combats.active) {
                    const combat = game.combats.active;
                    const combatant = (_c = combat.combatants) === null || _c === void 0 ? void 0 : _c.find((c) => { var _a; return ((_a = c === null || c === void 0 ? void 0 : c.actor) === null || _a === void 0 ? void 0 : _a._id) === this.actor.id; });
                    if (combatant) {
                        // @ts-ignore
                        combat.rollInitiative(combatant._id);
                    }
                    else {
                        RollService.rollInitiative(evt, this.actor);
                    }
                }
                else {
                    RollService.rollInitiative(evt, this.actor);
                }
            }
        });
    }
    createItem(type) {
        this.actor.createOwnedItem({ type, name: `New ${type}` }, { renderSheet: true });
    }
    editItem(type, id) {
        const item = this.actor.items.find((item) => item.type === type && (id == null || item.id === id));
        const sheet = getSheetClass(type);
        if (item && sheet) {
            new sheet(item).render(true);
        }
    }
    deleteItem(type, id) {
        const item = this.actor.items.find((item) => item.type === type && (id == null || item.id === id));
        if (item) {
            this.actor.deleteOwnedItem(item.id);
        }
    }
    addSplitterpunkt() {
        this.actor
            .update({
            id: this.actor.id,
            data: {
                splitterpunkte: {
                    value: Math.min(15, this.actor.data.data.splitterpunkte.value + 1),
                },
            },
        })
            .then(() => this.render());
    }
    removeSplitterpunkt() {
        this.actor
            .update({
            id: this.actor.id,
            data: {
                splitterpunkte: {
                    value: Math.max(0, this.actor.data.data.splitterpunkte.value - 1),
                },
            },
        })
            .then(() => this.render());
    }
    updateViewSpecificData(formData) {
        const viewHealth = formData["data.view.health.asString"];
        const viewMaxHealth = formData["data.view.health.max"];
        const viewFokus = formData["data.view.fokus.asString"];
        const viewMaxFokus = formData["data.view.fokus.max"];
        const viewInitiative = formData["data.view.initiative"];
        if (viewHealth) {
            const health = CalculationService.fromEKVString(viewHealth);
            formData["data.healthErschoepft"] = health.erschoepft;
            formData["data.healthKanalisiert"] = health.kanalisiert;
            formData["data.healthVerzehrt"] = health.verzehrt;
            delete formData["data.view.health.asString"];
            if (viewMaxHealth != null) {
                formData["data.health.value"] =
                    viewMaxHealth -
                        health.erschoepft -
                        health.kanalisiert -
                        health.verzehrt;
                formData["data.health.max"] = viewMaxHealth;
                formData["data.health.min"] = 0;
                delete formData["data.view.health.max"];
            }
        }
        if (viewFokus) {
            const fokus = CalculationService.fromEKVString(viewFokus);
            formData["data.fokusErschoepft"] = fokus.erschoepft;
            formData["data.fokusKanalisiert"] = fokus.kanalisiert;
            formData["data.fokusVerzehrt"] = fokus.verzehrt;
            delete formData["data.view.fokus.asString"];
            if (viewMaxFokus != null) {
                formData["data.fokus.value"] =
                    viewMaxFokus - fokus.erschoepft - fokus.kanalisiert - fokus.verzehrt;
                formData["data.fokus.max"] = viewMaxFokus;
                formData["data.fokus.min"] = 0;
                delete formData["data.view.fokus.max"];
            }
        }
        if (viewInitiative != null) {
            formData["data.initiativeTotal"] = viewInitiative;
            delete formData["data.view.initiative"];
        }
        return formData;
    }
    equipItem(type, id) {
        const item = this.actor.items.find((item) => item.type === type && (id == null || item.id === id));
        if (item) {
            const toUnequip = this.actor.items
                .filter((i) => i.type === type && i._id !== item._id)
                .map((i) => ({
                _id: i._id,
                data: {
                    isEquipped: false,
                },
            }));
            this.actor.updateOwnedItem([
                ...toUnequip,
                {
                    _id: item.id,
                    data: {
                        isEquipped: true,
                    },
                },
            ]);
        }
    }
    unequipItem(type, id) {
        const item = this.actor.items.find((item) => item.type === type && (id == null || item.id === id));
        if (item) {
            this.actor.updateOwnedItem({
                _id: item.id,
                data: {
                    isEquipped: false,
                },
            });
        }
    }
}
