import { SplimoActorSheet } from "../splimo-actor-sheet.js";
import { CalculationService } from "../../services/calculation-service.js";
import { ModifierService, } from "../../services/modifier-service.js";
import { ModifierType } from "../../models/items/modifier.js";
import { PlayerDataService } from "../../services/player-data-service.js";
import { ATTRIBUTES } from "../../models/actors/attributes.js";
import { DERIVED_ATTRIBUTES } from "../../models/actors/derived-attributes.js";
export class SplimoNpcSheet extends SplimoActorSheet {
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["splittermond"],
            template: "systems/splittermond/templates/sheets/actor/non-player-sheet.hbs",
            width: 1024,
            height: 754,
            tabs: [
                {
                    navSelector: ".sheet-tabs",
                    contentSelector: ".sheet-body",
                    initial: "attributes",
                },
                {
                    navSelector: ".fertigkeiten-tabs",
                    contentSelector: ".fertigkeiten-content",
                    initial: "allgemein",
                },
            ],
        });
    }
    getData() {
        const data = super.getData();
        const modifiers = {
            byType: new Map(),
            byTarget: new Map(),
            byItemType: new Map(),
        };
        const npcData = this
            .actor.data.data;
        const maxHealth = npcData.LP *
            (5 +
                ModifierService.totalMod(modifiers, null, {
                    modType: ModifierType.WoundLevels,
                }));
        const maxFokus = npcData.FO;
        data.data.view = {
            health: {
                max: maxHealth,
                current: maxHealth -
                    npcData.healthErschoepft -
                    npcData.healthVerzehrt -
                    npcData.healthKanalisiert,
                asString: CalculationService.toEKVString(npcData.healthErschoepft, npcData.healthKanalisiert, npcData.healthVerzehrt),
            },
            fokus: {
                max: maxFokus,
                current: maxFokus -
                    npcData.fokusErschoepft -
                    npcData.fokusVerzehrt -
                    npcData.fokusKanalisiert,
                asString: CalculationService.toEKVString(npcData.fokusErschoepft, npcData.fokusKanalisiert, npcData.fokusVerzehrt),
            },
        };
        data.data.merkmale = PlayerDataService.getMerkmale(this.actor, modifiers);
        data.data.zustaende = PlayerDataService.getZustaende(this.actor, modifiers);
        data.data.attributeModifier = [
            ...ATTRIBUTES,
            ...DERIVED_ATTRIBUTES,
        ].reduce((accu, attr) => {
            accu[attr] = ModifierService.totalMod(modifiers, attr, {
                modType: ModifierType.Attribute,
            });
            return accu;
        }, {});
        data.data.meisterschaften = PlayerDataService.getMeisterschaften(this.actor, modifiers);
        data.data.zauber = PlayerDataService.getZauber(this.actor, modifiers);
        return data;
    }
    activateListeners(html) {
        super.activateListeners(html);
        const query = html instanceof HTMLElement ? $(html) : html;
        // trash listener for skills
        query.on("click", ".fertigkeiten .fa-trash", (evt) => {
            var _a;
            const targetDataset = (_a = evt.currentTarget) === null || _a === void 0 ? void 0 : _a.dataset;
            if (targetDataset) {
                const deleteIdx = targetDataset["index"];
                this.actor.data.data.fertigkeiten.splice(+deleteIdx, 1);
                this.actor.update({
                    _id: this.actor._id,
                    data: {
                        fertigkeiten: this.actor.data.data.fertigkeiten,
                    },
                });
            }
        });
        // trash listener for weapons
        query.on("click", ".waffen .fa-trash", (evt) => {
            var _a;
            const targetDataset = (_a = evt.currentTarget) === null || _a === void 0 ? void 0 : _a.dataset;
            if (targetDataset) {
                const deleteIdx = targetDataset["index"];
                this.actor.data.data.waffen.splice(+deleteIdx, 1);
                this.actor.update({
                    _id: this.actor._id,
                    data: {
                        waffen: this.actor.data.data.waffen,
                    },
                });
            }
        });
    }
    _updateObject(event, formData) {
        formData = this.updateViewSpecificData(formData);
        const fertigkeiten = this.actor.data.data.fertigkeiten;
        for (let i = 0; i < fertigkeiten.length; i++) {
            fertigkeiten[i].name = formData[`data.fertigkeiten[${i}].name`];
            fertigkeiten[i].wert = formData[`data.fertigkeiten[${i}].wert`];
            delete formData[`data.fertigkeiten[${i}].name`];
            delete formData[`data.fertigkeiten[${i}].name`];
        }
        const newFertigkeitName = formData["data.newFertigkeit.name"];
        if (newFertigkeitName && newFertigkeitName.trim().length > 0) {
            delete formData["data.newFertigkeit.name"];
            const newFertigkeit = { name: newFertigkeitName, wert: 0 };
            fertigkeiten.push(newFertigkeit);
        }
        const waffen = this.actor.data.data.waffen;
        for (let i = 0; i < waffen.length; i++) {
            waffen[i].name = formData[`data.waffen[${i}].name`];
            waffen[i].wert = formData[`data.waffen[${i}].wert`];
            waffen[i].wgs = formData[`data.waffen[${i}].wgs`];
            waffen[i].schaden = formData[`data.waffen[${i}].schaden`];
            waffen[i].merkmale = formData[`data.waffen[${i}].merkmale`];
            delete formData[`data.waffen[${i}].name`];
            delete formData[`data.waffen[${i}].wert`];
            delete formData[`data.waffen[${i}].wgs`];
            delete formData[`data.waffen[${i}].schaden`];
            delete formData[`data.waffen[${i}].merkmale`];
        }
        const newWaffeName = formData["data.newWaffe.name"];
        if (newWaffeName && newWaffeName.trim().length > 0) {
            delete formData["data.newWaffe.name"];
            waffen.push({
                name: newWaffeName,
                wgs: 0,
                wert: 0,
                schaden: "",
                merkmale: "",
            });
        }
        return this.actor
            .update({
            _id: this.actor.id,
            data: {
                fertigkeiten: fertigkeiten,
                waffen: waffen,
            },
        })
            .then(() => super._updateObject(event, formData))
            .then(() => CalculationService.updateWoundModifier(this.actor));
    }
}
