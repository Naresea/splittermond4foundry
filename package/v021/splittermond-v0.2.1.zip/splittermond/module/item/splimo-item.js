export class SplimoItem extends Item {
    static get config() {
        const conf = super.config;
        conf.embeddedEntities = Object.assign(Object.assign({}, conf.embeddedEntities), { OwnedItem: "OwnedItem" });
        return conf;
    }
}
