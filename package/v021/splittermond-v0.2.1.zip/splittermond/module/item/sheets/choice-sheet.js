import { ChargenOptionType, } from "../../models/items/chargen.js";
import { ChargenOptionsSheet } from "./chargen-options-sheet.js";
export class ChoiceSheet extends FormApplication {
    constructor(object, options, update) {
        super(object, options);
        this.update = update;
    }
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["splittermond"],
            template: "systems/splittermond/templates/sheets/item/choice-sheet.hbs",
            width: 512,
            height: 766,
            tabs: [],
            submitOnChange: true,
            submitOnClose: true,
            closeOnSubmit: false,
            editable: true,
        });
    }
    getData(options) {
        var _a;
        return Object.assign(Object.assign({}, this.object), { typeLabels: [
                "splittermond.chargen.typelabels.FixedValue",
                "splittermond.chargen.typelabels.SelectOneOf",
                "splittermond.chargen.typelabels.SelectNOf",
                "splittermond.chargen.typelabels.DistributePoints",
                "splittermond.chargen.typelabels.MatchMultiple",
            ], availableTypes: [
                "FixedValue",
                "SelectOneOf",
                "SelectNOf",
                "DistributePoints",
                "MatchMultiple",
            ], optionFields: [
                "splittermond.chargen-choices.optionType",
                "splittermond.chargen-choices.optionNames",
                "splittermond.chargen-choices.points",
            ], pointOptions: ((_a = this.object.pointOptions) !== null && _a !== void 0 ? _a : []).join(", "), optionsTable: this.object.options.map((op) => {
                var _a;
                return ({
                    fields: [
                        `splittermond.chargen-option-label.type.${op.type}`,
                        `${op.name}`,
                        `${(_a = op.points) !== null && _a !== void 0 ? _a : 0}`,
                    ],
                });
            }) });
    }
    activateListeners(html) {
        super.activateListeners(html);
        if (html instanceof HTMLElement) {
            return;
        }
        html.find(".choice-options .add-item").on("click", (evt) => {
            this.addChoice(evt);
        });
        html.find(".choice-options .edit-item").on("click", (evt) => {
            this.editChoice(evt);
        });
        html.find(".choice-options .delete-item").on("click", (evt) => {
            this.deleteChoice(evt);
        });
    }
    _updateObject(event, formData) {
        return this.doUpdate(formData);
    }
    doUpdate(formData) {
        var _a, _b, _c, _d;
        this.object.choiceType = (_a = formData.choiceType) !== null && _a !== void 0 ? _a : this.object.choiceType;
        this.object.numN = (_b = formData.numN) !== null && _b !== void 0 ? _b : this.object.numN;
        this.object.numPoints =
            (_c = formData.numPoints) !== null && _c !== void 0 ? _c : this.object.numPoints;
        this.object.pointOptions =
            (_d = this.parsePointOptions(formData.pointOptions)) !== null && _d !== void 0 ? _d : this.object.pointOptions;
        this.render();
        return this.update
            ? this.update(formData)
            : Promise.reject("No update defined.");
    }
    parsePointOptions(opts) {
        return opts === null || opts === void 0 ? void 0 : opts.split(",").map((s) => s.trim()).map((s) => (Number.isNumeric(s) ? +s : undefined)).filter((s) => s != null);
    }
    addChoice(evt) {
        if (!evt || !evt.currentTarget || !evt.currentTarget.dataset) {
            return;
        }
        const opt = {
            type: ChargenOptionType.Attribute,
            name: "",
        };
        this.object.options.push(opt);
        this.openChargenOptionSheet(this.object.options, this.object.options.length - 1);
    }
    editChoice(evt) {
        if (!evt || !evt.currentTarget || !evt.currentTarget.dataset) {
            return;
        }
        const idx = evt.currentTarget.dataset["index"];
        if (Number.isNumeric(idx)) {
            this.openChargenOptionSheet(this.object.options, +idx);
        }
    }
    deleteChoice(evt) {
        if (!evt || !evt.currentTarget || !evt.currentTarget.dataset) {
            return;
        }
        const idx = evt.currentTarget.dataset["index"];
        if (Number.isNumeric(idx)) {
            this.object.options.splice(idx, 1);
        }
    }
    openChargenOptionSheet(options, index) {
        const opt = options[index];
        new ChargenOptionsSheet(opt, {}, (data) => {
            this.doUpdate({
                options: [...options],
            });
        }).render(true);
    }
}
