export class ChargenOptionsSheet extends FormApplication {
    constructor(object, options, update) {
        super(object, options);
        this.update = update;
    }
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["splittermond"],
            template: "systems/splittermond/templates/sheets/item/chargen-option-sheet.hbs",
            width: 512,
            height: 766,
            tabs: [
                {
                    navSelector: ".sheet-tabs",
                    contentSelector: ".sheet-body",
                    initial: "description",
                },
            ],
            submitOnChange: true,
            submitOnClose: true,
            closeOnSubmit: false,
            editable: true,
        });
    }
    getData(options) {
        var _a;
        return Object.assign(Object.assign({}, this.object), { typeLabels: [
                "splittermond.chargen-option.typelabels.fertigkeit",
                "splittermond.chargen-option.typelabels.meisterschaft",
                "splittermond.chargen-option.typelabels.resource",
                "splittermond.chargen-option.typelabels.staerke",
                "splittermond.chargen-option.typelabels.schwaeche",
                "splittermond.chargen-option.typelabels.attribute",
            ], availableTypes: [
                "fertigkeit",
                "meisterschaft",
                "resource",
                "staerke",
                "schwaeche",
                "attribute",
            ], masteryLevelFilter: ((_a = this.object.masteryLevelFilter) !== null && _a !== void 0 ? _a : []).join(", ") });
    }
    _updateObject(event, formData) {
        var _a, _b, _c, _d, _e, _f;
        this.object.type = (_a = formData.type) !== null && _a !== void 0 ? _a : this.object.type;
        this.object.name = (_b = formData.name) !== null && _b !== void 0 ? _b : this.object.name;
        this.object.points = (_c = formData.points) !== null && _c !== void 0 ? _c : this.object.points;
        this.object.skillTypeFilter =
            (_d = formData.skillTypeFilter) !== null && _d !== void 0 ? _d : this.object.skillTypeFilter;
        this.object.masterySkillFilter =
            (_e = formData.masterySkillFilter) !== null && _e !== void 0 ? _e : this.object.masterySkillFilter;
        this.object.masteryLevelFilter =
            (_f = this.mapMasterySkillFilter(formData.masteryLevelFilter)) !== null && _f !== void 0 ? _f : this.object.masteryLevelFilter;
        this.render();
        return this.update
            ? this.update(formData)
            : Promise.reject("No update defined.");
    }
    mapMasterySkillFilter(filter) {
        return filter === null || filter === void 0 ? void 0 : filter.split(",").map((s) => s.trim()).map((s) => (Number.isNumeric(s) ? +s : undefined)).filter((s) => s != null);
    }
}
