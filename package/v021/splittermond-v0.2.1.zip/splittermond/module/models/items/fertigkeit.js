export var FertigkeitType;
(function (FertigkeitType) {
    FertigkeitType["Allgemein"] = "allgemein";
    FertigkeitType["Kampf"] = "kampf";
    FertigkeitType["Magie"] = "magie";
})(FertigkeitType || (FertigkeitType = {}));
