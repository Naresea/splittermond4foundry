export class TickDialog extends FormApplication {
    constructor(object, options, submit) {
        super(object, options);
        this.submitCallback = submit;
    }
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["splittermond"],
            template: "systems/splittermond/templates/sheets/popups/tick-dialog.hbs",
            width: 512,
            height: 340,
            submitOnChange: false,
            submitOnClose: false,
            closeOnSubmit: true,
            editable: true,
        });
    }
    getData(options) {
        return this.object;
    }
    activateListeners(html) {
        super.activateListeners(html);
        if (html instanceof HTMLElement) {
            console.error("TickDialog: html is of wrong type.");
            return;
        }
        html.find(".clickable").on("click", (evt) => {
            var _a, _b, _c;
            const dataset = (_a = evt === null || evt === void 0 ? void 0 : evt.currentTarget) === null || _a === void 0 ? void 0 : _a.dataset;
            if (dataset) {
                const submitValue = dataset["ticksSubmit"];
                if (submitValue === "ok") {
                    const modifier = html.find('input[name="data.ticks"]').get()[0];
                    const value = (_c = +((_b = modifier) === null || _b === void 0 ? void 0 : _b.value)) !== null && _c !== void 0 ? _c : 0;
                    if (this.submitCallback) {
                        this.submitCallback({
                            modifier: value,
                        });
                    }
                }
                else {
                    if (this.submitCallback) {
                        this.submitCallback(undefined);
                    }
                }
                this.close();
            }
        });
    }
    _updateObject(event, formData) {
        return Promise.resolve();
    }
}
