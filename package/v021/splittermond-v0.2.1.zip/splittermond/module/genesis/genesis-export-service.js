import { PlayerDataService, } from "../services/player-data-service.js";
import { buildFokusString } from "../models/items/zauber.js";
const GENESIS_ATTRIBUTE_IDS = {
    AUS: "CHARISMA",
    BEW: "AGILITY",
    INT: "INTUITION",
    KON: "CONSTITUTION",
    MYS: "MYSTIC",
    STR: "STRENGTH",
    VER: "MIND",
    WIL: "WILLPOWER",
    SPL: "SPLINTER",
    GK: "SIZE",
    GSW: "SPEED",
    INI: "INITIATIVE",
    LP: "LIFE",
    FO: "FOCUS",
    VTD: "DEFENSE",
    SR: "DAMAGE_REDUCTION",
    GW: "MINDRESIST",
    KW: "BODYRESIST",
};
export class GenesisExportService {
    static exportToGenesis(actor) {
        const filename = `fvtt-${actor.entity}-${actor.name.replace(/\s/g, "_")}.json`;
        const data = GenesisExportService.mapToGenesisJson(actor);
        saveDataToFile(JSON.stringify(data), "text/json", filename);
    }
    static mapToGenesisJson(actor) {
        const data = {};
        const playerData = PlayerDataService.getPlayerData(actor);
        GenesisExportService.exportBiography(actor, playerData, data);
        GenesisExportService.exportAttributes(actor, playerData, data);
        GenesisExportService.exportFertigkeiten(actor, playerData, data);
        GenesisExportService.exportStaerken(actor, playerData, data);
        GenesisExportService.exportZauber(actor, playerData, data);
        GenesisExportService.exportResourcen(actor, playerData, data);
        GenesisExportService.exportRuestungen(actor, playerData, data);
        GenesisExportService.exportWaffen(actor, playerData, data);
        GenesisExportService.exportSchilde(actor, playerData, data);
        GenesisExportService.exportGegenstaende(actor, playerData, data);
        GenesisExportService.exportMondzeichen(actor, playerData, data);
        return data;
    }
    static exportBiography(actor, playerData, data) {
        var _a, _b, _c, _d, _e, _f;
        data.name = playerData.biography.name;
        data.gender = (_a = actor.data.data.geschlecht) !== null && _a !== void 0 ? _a : null;
        data.hairColor = (_b = actor.data.data.haarfarbe) !== null && _b !== void 0 ? _b : null;
        data.size = Number.isNumeric(actor.data.data.koerpergroesse)
            ? +actor.data.data.koerpergroesse
            : null;
        data.eyeColor = actor.data.data.augenfarbe;
        data.weight = Number.isNumeric(actor.data.data.gewicht)
            ? +actor.data.data.gewicht
            : null;
        data.furColor = actor.data.data.hautfarbe;
        data.birthplace = actor.data.data.geburtsort;
        data.investedExp = actor.data.data.erfahrungEingesetzt;
        data.freeExp =
            actor.data.data.erfahrungGesamt - actor.data.data.erfahrungEingesetzt;
        data.race = playerData.biography.rasse;
        data.education = playerData.biography.ausbildung;
        data.culture = playerData.biography.kultur;
        data.background = playerData.biography.abstammung;
        const cultureItem = actor.items.find((i) => i.type === "kultur" /* Kultur */);
        data.cultureLores = (_d = (_c = cultureItem) === null || _c === void 0 ? void 0 : _c.data.data.kulturkunde) === null || _d === void 0 ? void 0 : _d.split(",").map((s) => s.trim());
        data.languages = (_f = (_e = cultureItem) === null || _e === void 0 ? void 0 : _e.data.data.sprache) === null || _f === void 0 ? void 0 : _f.split(",").map((s) => s.trim());
        data.weaknesses = actor.items
            .filter((i) => i.type === "schwaeche" /* Schwaeche */)
            .map((i) => i.name);
    }
    static exportAttributes(actor, playerData, data) {
        const attributes = Object.keys(playerData.attributes).map((shortName) => ({
            name: playerData.attributes[shortName].name,
            shortName: shortName === "STR" ? "STÄ" : shortName,
            value: playerData.attributes[shortName].total,
            startValue: playerData.attributes[shortName].start,
            id: GENESIS_ATTRIBUTE_IDS[shortName],
        }));
        const derivedAttributes = Object.keys(playerData.derivedAttributes).map((shortName) => ({
            name: playerData.derivedAttributes[shortName].name,
            shortName: shortName === "STR" ? "STÄ" : shortName,
            value: playerData.derivedAttributes[shortName].total,
            startValue: playerData.derivedAttributes[shortName].start,
            id: GENESIS_ATTRIBUTE_IDS[shortName],
        }));
        const splitterpunkte = {
            name: 'Splitterpunkte',
            shortName: 'SPL',
            value: actor.data.data.splitterpunkte.max,
            startValue: actor.data.data.splitterpunkte.max,
            id: GENESIS_ATTRIBUTE_IDS['SPL']
        };
        data.attributes = [...attributes, ...derivedAttributes];
    }
    static exportFertigkeiten(actor, playerData, data) {
        data.skills = [
            ...playerData.fertigkeiten.tableData,
            ...playerData.kampfFertigkeiten.tableData,
            ...playerData.magieFertigkeiten.tableData,
        ]
            .map((fertigkeit) => {
            var _a;
            const item = actor.getOwnedItem(fertigkeit.id);
            if (!item || item.type !== "fertigkeit" /* Fertigkeit */) {
                return undefined;
            }
            return {
                name: item.name,
                attribute1: (item.data.data.attributEins === "STR"
                    ? "STÄ"
                    : item.data.data.attributEins),
                attribute2: (item.data.data.attributZwei === "STR"
                    ? "STÄ"
                    : item.data.data.attributZwei),
                value: (_a = fertigkeit.roll) !== null && _a !== void 0 ? _a : 0,
                points: item.data.data.punkte,
                modifier: 0,
                masterships: playerData.meisterschaften.tableData
                    .map((mastery) => {
                    const masteryItem = actor.items.get(mastery.id);
                    if (!masteryItem || masteryItem.type !== "meisterschaft" /* Meisterschaft */) {
                        return undefined;
                    }
                    if (masteryItem.data.data.fertigkeit !== item.name) {
                        return undefined;
                    }
                    return {
                        name: masteryItem.name,
                        level: masteryItem.data.data.schwelle,
                        shortDescription: "",
                        longDescription: masteryItem.data.data.beschreibung,
                        page: `${masteryItem.data.data.regelwerk} ${masteryItem.data.data.seite}`,
                    };
                })
                    .filter((m) => m != null),
            };
        })
            .filter((v) => v != null);
    }
    static exportStaerken(actor, playerData, data) {
        data.powers = actor.items
            .filter((i) => i.type === "staerke" /* Staerke */)
            .map((i) => ({
            name: i.name,
            count: i.data.data.level,
            shortDescription: "",
            longDescription: i.data.data.beschreibung,
            page: `${i.data.data.regelwerk} ${i.data.data.seite}`,
        }));
    }
    static exportZauber(actor, playerData, data) {
        data.spells = playerData.zauber.tableData
            .map((zauber) => {
            const item = actor.items.get(zauber.id);
            if (!item || item.type !== "zauber" /* Zauber */) {
                return undefined;
            }
            return {
                name: item.name,
                value: zauber.roll,
                school: item.data.data.fertigkeit,
                schoolGrade: item.data.data.grad,
                difficulty: item.data.data.schwierigkeitString,
                focus: buildFokusString(item.data.data),
                castDuration: item.data.data.zauberdauerString,
                castRange: item.data.data.reichweiteString,
                spellDuration: item.data.data.wirkungsdauerString,
                enhancement: item.data.data.verstaerkung,
                longDescription: item.data.data.beschreibung,
                page: `${item.data.data.regelwerk} ${item.data.data.seite}`,
            };
        })
            .filter((z) => z != null);
    }
    static exportResourcen(actor, playerData, data) {
        data.resources = actor.items
            .filter((i) => i.type === "resource" /* Resource */)
            .map((i) => ({
            name: i.name,
            value: i.data.data.punkte,
            description: i.data.data.beschreibung,
        }));
    }
    static exportRuestungen(actor, playerData, data) {
        data.armors = playerData.ruestungen.tableData
            .map((ruestung) => {
            const item = actor.items.get(ruestung.id);
            if (!item || item.type !== "ruestung" /* Ruestung */) {
                return undefined;
            }
            return {
                name: item.name,
                defense: item.data.data.VTD,
                handicap: item.data.data.BEH,
                damageReduction: item.data.data.SR,
                tickMalus: item.data.data.tickPlus,
                features: item.data.data.merkmale
                    .split(",")
                    .map((s) => s.trim())
                    .map((featName) => ({
                    name: featName,
                })),
            };
        })
            .filter((v) => v != null);
    }
    static exportSchilde(actor, playerData, data) {
        data.shields = playerData.schilde.tableData
            .map((schild) => {
            const item = actor.items.get(schild.id);
            if (!item || item.type !== "schild" /* Schild */) {
                return undefined;
            }
            return {
                name: item.name,
                activeDefenseValue: schild.roll,
                skill: item.data.data.fertigkeit,
                attack: schild.roll,
                damage: item.data.data.schaden,
                defensePlus: item.data.data.VTD,
                handicap: item.data.data.BEH,
                tickMalus: item.data.data.tickPlus,
                features: item.data.data.merkmale
                    .split(",")
                    .map((s) => s.trim())
                    .map((featName) => ({
                    name: featName,
                })),
            };
        })
            .filter((v) => v != null);
    }
    static exportWaffen(actor, playerData, data) {
        data.meleeWeapons = playerData.waffen.tableData
            .map((waffe) => {
            const item = actor.items.get(waffe.id);
            if (!item ||
                item.type !== "waffe" /* Waffe */ ||
                item.data.data.reichweite) {
                return undefined;
            }
            return {
                name: item.name,
                skill: item.data.data.fertigkeit,
                attribute1: item.data.data.attribute,
                attribute2: item.data.data.attributeSecondary,
                value: waffe.roll,
                damage: item.data.data.schaden,
                weaponSpeed: item.data.data.ticks,
                calculateSpeed: JSON.parse(waffe.rollInfo).ticks,
                features: item.data.data.merkmale
                    .split(",")
                    .map((s) => s.trim())
                    .map((featName) => ({
                    name: featName,
                })),
            };
        })
            .filter((v) => v != null);
        data.longRangeWeapons = playerData.waffen.tableData
            .map((waffe) => {
            const item = actor.items.get(waffe.id);
            if (!item ||
                item.type !== "waffe" /* Waffe */ ||
                !item.data.data.reichweite) {
                return undefined;
            }
            return {
                name: item.name,
                skill: item.data.data.fertigkeit,
                attribute1: item.data.data.attribute,
                attribute2: item.data.data.attributeSecondary,
                value: waffe.roll,
                damage: item.data.data.schaden,
                weaponSpeed: item.data.data.ticks,
                calculateSpeed: JSON.parse(waffe.rollInfo).ticks,
                range: item.data.data.reichweite,
                features: item.data.data.merkmale
                    .split(",")
                    .map((s) => s.trim())
                    .map((featName) => ({
                    name: featName,
                })),
            };
        })
            .filter((v) => v != null);
    }
    static exportGegenstaende(actor, playerData, data) {
        data.items = [
            ...playerData.benutzbares.tableData,
            ...playerData.sonstiges.tableData,
        ]
            .map((gegenstand) => {
            const item = actor.items.get(gegenstand.id);
            if (!item ||
                !["benutzbar" /* Benutzbar */, "gegenstand" /* Gegenstand */].includes(item.type)) {
                return undefined;
            }
            return {
                name: item.name,
                count: item.data.data.anzahl,
            };
        })
            .filter((v) => v != null);
    }
    static exportMondzeichen(actor, playerData, data) {
        const moonsignItem = actor.items.find((i) => i.type === "mondzeichen" /* Mondzeichen */);
        if (!moonsignItem) {
            return;
        }
        data.moonSign = {
            name: moonsignItem.name,
            description: moonsignItem.data.data.beschreibung,
        };
    }
}
