import { ChargenOptionType, ChoiceType, } from "../models/items/chargen.js";
import { ATTRIBUTES } from "../models/actors/attributes.js";
import { DERIVED_ATTRIBUTES } from "../models/actors/derived-attributes.js";
import { ChargenSelectOne } from "../popups/chargen-select-one.js";
import { ChargenSelectMany } from "../popups/chargen-select-many.js";
import { ChargenDistributePoints } from "../popups/chargen-distribute-points.js";
import { ChargenMatchMultiple } from "../popups/chargen-match-multiple.js";
export class ChargenService {
    static async applyChargenData(actor, chargenItem) {
        var _a, _b, _c, _d, _e;
        if (!ChargenService.CHARGEN_ITEM_TYPES.includes(chargenItem.type)) {
            return;
        }
        const data = chargenItem.data.data;
        const sorted = data.choices.reduce((accu, choice) => {
            var _a;
            const arr = (_a = accu.get(choice.choiceType)) !== null && _a !== void 0 ? _a : [];
            arr.push(choice);
            accu.set(choice.choiceType, arr);
            return accu;
        }, new Map());
        await ChargenService.applyFixed(actor, (_a = sorted.get(ChoiceType.FixedValue)) !== null && _a !== void 0 ? _a : []);
        await ChargenService.applySelectOne(actor, (_b = sorted.get(ChoiceType.SelectOneOf)) !== null && _b !== void 0 ? _b : []);
        await ChargenService.applySelectMany(actor, (_c = sorted.get(ChoiceType.SelectNOf)) !== null && _c !== void 0 ? _c : []);
        await ChargenService.applyDistributePoints(actor, (_d = sorted.get(ChoiceType.DistributePoints)) !== null && _d !== void 0 ? _d : []);
        await ChargenService.applyMatchMultiple(actor, (_e = sorted.get(ChoiceType.MatchMultiple)) !== null && _e !== void 0 ? _e : []);
    }
    static async applyFixed(actor, choices) {
        const fixedChoices = choices;
        const options = fixedChoices
            .map((choice) => choice.options)
            .reduce((accu, curr) => {
            accu.push(...curr);
            return accu;
        }, []);
        return this.applySelectedOptions(actor, options);
    }
    static async applySelectOne(actor, choices) {
        const selectOneChoices = choices;
        const selectedOptions = (await Promise.all(selectOneChoices.map((choice) => {
            return new Promise((resolve) => {
                new ChargenSelectOne(choice, {}, (option) => resolve(option)).render(true);
            });
        })));
        await this.applySelectedOptions(actor, selectedOptions.filter((o) => o != null));
    }
    static async applySelectMany(actor, choices) {
        await this.applyMultipleOptions(actor, choices, ChargenSelectMany);
    }
    static async applyDistributePoints(actor, choices) {
        await this.applyMultipleOptions(actor, choices, ChargenDistributePoints);
    }
    static async applyMatchMultiple(actor, choices) {
        await this.applyMultipleOptions(actor, choices, ChargenMatchMultiple);
    }
    // TODO: figure out what the correct type for "constructor of a FormApplication" is
    static async applyMultipleOptions(actor, choices, dialogClass) {
        const selectedOptions = (await Promise.all(choices.map((choice) => {
            return new Promise((resolve) => {
                new dialogClass(choice, {}, (option) => resolve(option)).render(true);
            });
        })));
        const flattened = selectedOptions.reduce((accu, curr) => {
            accu.push(...curr);
            return accu;
        }, []);
        console.log("Received selected options: ", flattened);
        await this.applySelectedOptions(actor, flattened.filter((o) => o != null));
    }
    static async applySelectedOptions(actor, chargenOptions) {
        const data = await Promise.all(chargenOptions.map((option) => ChargenService.applyChargenOption(actor, option)));
        await actor.updateEmbeddedEntity("OwnedItem", data.filter((d) => d != null));
    }
    static applyChargenOption(actor, chargenOption) {
        if (chargenOption.type === ChargenOptionType.Attribute) {
            return ChargenService.applyAttribute(actor, chargenOption);
        }
        if (chargenOption.type === ChargenOptionType.Mastery) {
            return ChargenService.addToActor(actor, chargenOption, "meisterschaft" /* Meisterschaft */);
        }
        if (chargenOption.type === ChargenOptionType.Resource) {
            return ChargenService.applyPoints(actor, chargenOption, "resource" /* Resource */);
        }
        if (chargenOption.type === ChargenOptionType.Skill) {
            return ChargenService.applyPoints(actor, chargenOption, "fertigkeit" /* Fertigkeit */);
        }
        if (chargenOption.type === ChargenOptionType.Strength) {
            return ChargenService.addToActor(actor, chargenOption, "staerke" /* Staerke */);
        }
        if (chargenOption.type === ChargenOptionType.Weakness) {
            return ChargenService.addToActor(actor, chargenOption, "schwaeche" /* Schwaeche */);
        }
    }
    static applyAttribute(actor, chargenOption) {
        const name = chargenOption.name;
        const points = chargenOption.points;
        if ([...ATTRIBUTES, ...DERIVED_ATTRIBUTES].includes(name) &&
            points != null) {
            actor.data.data[name] += points;
            return actor
                .update({
                _id: actor._id,
                data: {
                    [name]: actor.data.data[name],
                },
            })
                .then(() => undefined);
        }
    }
    static applyPoints(actor, chargenOption, type) {
        const name = chargenOption.name;
        if (name == null || name.length < 1) {
            return Promise.resolve(undefined);
        }
        return ChargenService.findItem(actor, type, name).then((i) => {
            if (i) {
                i.data.data.punkte += chargenOption.points;
                return {
                    _id: i._id,
                    data: {
                        punkte: i.data.data.punkte,
                    },
                };
            }
            return Promise.resolve(undefined);
        });
    }
    static addToActor(actor, chargenOption, type) {
        const name = chargenOption.name;
        if (name == null || name.length < 1) {
            return Promise.resolve(undefined);
        }
        return ChargenService.findItem(actor, type, name).then(() => undefined);
    }
    static findItem(actor, type, name) {
        const actorOwnedItem = actor.items.find((i) => i.type === type && i.name === name);
        if (actorOwnedItem) {
            return Promise.resolve(actorOwnedItem);
        }
        const globalItem = game.items.find((i) => i.type === type && i.name === name);
        if (globalItem) {
            // create a copy of the global item for the current actor
            return actor
                .createOwnedItem({
                type: globalItem.type,
                name: globalItem.name,
                data: globalItem.data,
            })
                .then((i) => {
                return i;
            });
        }
        return Promise.resolve(undefined);
    }
}
ChargenService.CHARGEN_ITEM_TYPES = [
    "rasse" /* Rasse */,
    "kultur" /* Kultur */,
    "abstammung" /* Abstammung */,
    "ausbildung" /* Ausbildung */,
];
