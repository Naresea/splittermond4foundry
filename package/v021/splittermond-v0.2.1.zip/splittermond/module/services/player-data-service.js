import { ATTRIBUTES } from "../models/actors/attributes.js";
import { ModifierService } from "./modifier-service.js";
import { ModifierType } from "../models/items/modifier.js";
import { FertigkeitType } from "../models/items/fertigkeit.js";
import { CalculationService } from "./calculation-service.js";
import { buildFokusString } from "../models/items/zauber.js";
export class PlayerDataService {
    static getPlayerData(actor) {
        const modifiers = ModifierService.getModifiers(actor);
        const biography = PlayerDataService.getBiography(actor);
        const attributes = PlayerDataService.getAttributes(actor, modifiers);
        const derivedAttributes = PlayerDataService.getDerivedAttributes(actor, modifiers, attributes);
        const fertigkeiten = PlayerDataService.getFertigkeitenByType(actor, modifiers, FertigkeitType.Allgemein);
        const kampfFertigkeiten = PlayerDataService.getFertigkeitenByType(actor, modifiers, FertigkeitType.Kampf);
        const magieFertigkeiten = PlayerDataService.getFertigkeitenByType(actor, modifiers, FertigkeitType.Magie);
        const waffen = PlayerDataService.getWaffen(actor, modifiers);
        const ruestungen = PlayerDataService.getRuestungen(actor, modifiers);
        const schilde = PlayerDataService.getSchilde(actor, modifiers);
        const benutzbares = PlayerDataService.getBenutzbares(actor, modifiers);
        const sonstiges = PlayerDataService.getSonstiges(actor, modifiers);
        const zauber = PlayerDataService.getZauber(actor, modifiers);
        const view = PlayerDataService.getViewSpecificData(actor, modifiers, attributes, derivedAttributes);
        const meisterschaften = PlayerDataService.getMeisterschaften(actor, modifiers);
        const staerken = PlayerDataService.getStaerken(actor, modifiers);
        const schwaechen = PlayerDataService.getSchwaechen(actor, modifiers);
        const zustaende = PlayerDataService.getZustaende(actor, modifiers);
        const merkmale = PlayerDataService.getMerkmale(actor, modifiers);
        const resourcen = PlayerDataService.getResourcen(actor, modifiers);
        const mondzeichen = PlayerDataService.getMondzeichen(actor, modifiers);
        return Object.assign(Object.assign({}, actor.data.data), { biography,
            attributes,
            derivedAttributes,
            fertigkeiten,
            kampfFertigkeiten,
            magieFertigkeiten,
            waffen,
            ruestungen,
            schilde,
            benutzbares,
            sonstiges,
            zauber,
            view,
            meisterschaften,
            staerken,
            schwaechen,
            merkmale,
            zustaende,
            resourcen,
            mondzeichen });
    }
    static getBiography(actor) {
        var _a, _b, _c, _d;
        const rasse = actor.items.find((i) => i.type === "rasse" /* Rasse */);
        const abstammung = actor.items.find((i) => i.type === "abstammung" /* Abstammung */);
        const kultur = actor.items.find((i) => i.type === "kultur" /* Kultur */);
        const ausbildung = actor.items.find((i) => i.type === "ausbildung" /* Ausbildung */);
        return {
            name: actor.name,
            rasse: (_a = rasse === null || rasse === void 0 ? void 0 : rasse.name) !== null && _a !== void 0 ? _a : "",
            abstammung: (_b = abstammung === null || abstammung === void 0 ? void 0 : abstammung.name) !== null && _b !== void 0 ? _b : "",
            kultur: (_c = kultur === null || kultur === void 0 ? void 0 : kultur.name) !== null && _c !== void 0 ? _c : "",
            ausbildung: (_d = ausbildung === null || ausbildung === void 0 ? void 0 : ausbildung.name) !== null && _d !== void 0 ? _d : "",
        };
    }
    static getWoundModifier(actor) {
        const modifierItem = actor.items.find((i) => i.type === "zustand" /* Zustand */ &&
            i.data.data.internalId ===
                CalculationService.WOUND_MODIFIER_ID);
        if (!modifierItem) {
            return undefined;
        }
        return {
            name: modifierItem === null || modifierItem === void 0 ? void 0 : modifierItem.data.data.beschreibung,
            modifier: modifierItem === null || modifierItem === void 0 ? void 0 : modifierItem.data.data.modifier[0].value,
        };
    }
    static getAttributes(actor, mods) {
        return ATTRIBUTES.reduce((accu, attr) => {
            var _a, _b;
            const modifier = ModifierService.totalMod(mods, attr, {
                modType: ModifierType.Attribute,
            });
            const start = (_a = actor.data.data[attr]) !== null && _a !== void 0 ? _a : 0;
            const increased = (_b = actor.data.data[("inc" + attr)]) !== null && _b !== void 0 ? _b : 0;
            const total = start + increased + modifier;
            accu[attr] = {
                name: `attribute.${attr}`,
                start,
                increased,
                total,
                modifier,
            };
            return accu;
        }, {});
    }
    static getDerivedAttributes(actor, mods, attributes) {
        const baseValues = {
            GSW: attributes.GK.total + attributes.BEW.total,
            INI: 10 - attributes.INT.total,
            LP: attributes.GK.total + attributes.KON.total,
            FO: 2 * (attributes.MYS.total + attributes.WIL.total),
            VTD: 12 + attributes.BEW.total + attributes.STR.total,
            GW: 12 + attributes.VER.total + attributes.WIL.total,
            KW: 12 + attributes.KON.total + attributes.WIL.total,
        };
        return Object.keys(baseValues).reduce((accu, attr) => {
            var _a;
            const modifier = ModifierService.totalMod(mods, attr, {
                modType: ModifierType.Attribute,
            });
            const start = (_a = baseValues[attr]) !== null && _a !== void 0 ? _a : 0;
            const total = start + modifier;
            accu[attr] = {
                name: `attribute.${attr}`,
                start,
                increased: 0,
                total,
                modifier,
            };
            return accu;
        }, {});
    }
    static getFertigkeitenByType(actor, mods, ...fertigkeitType) {
        const tableFields = [
            "splittermond.fertigkeiten.name",
            "splittermond.fertigkeiten.wert",
            "splittermond.fertigkeiten.punkte",
            "splittermond.fertigkeiten.attributEins",
            "splittermond.fertigkeiten.attributZwei",
            "splittermond.fertigkeiten.modifier",
        ];
        const getFields = (fertigkeit) => {
            const roll = CalculationService.getFertigkeitsValue(actor, fertigkeit.name, mods);
            const fields = [
                fertigkeit.name,
                `${roll.total}`,
                `${fertigkeit.data.data.punkte}`,
                fertigkeit.data.data.attributEins,
                fertigkeit.data.data.attributZwei,
                `${fertigkeit.data.data.mod}`,
            ];
            return {
                fields,
                roll: roll.total,
                rollInfo: JSON.stringify({
                    name: fertigkeit.name,
                    explanation: roll.explanation,
                }),
            };
        };
        return PlayerDataService.getTableData(actor, mods, (item) => item.type === "fertigkeit" /* Fertigkeit */ &&
            fertigkeitType.includes(item.data.data.type), tableFields, getFields);
    }
    static getWaffen(actor, mods) {
        const tableFields = [
            "splittermond.inventar.waffen.name",
            "splittermond.inventar.waffen.wert",
            "splittermond.inventar.waffen.fertigkeit",
            "splittermond.inventar.waffen.wgs",
            "splittermond.inventar.waffen.schaden",
            "splittermond.inventar.waffen.merkmale",
        ];
        const getFields = (waffe) => {
            const roll = CalculationService.getWaffeOrSchildValue(actor, waffe.data.data, mods, waffe.name);
            const tickPlus = ModifierService.totalModWithExplanation(mods, null, {
                modType: ModifierType.TickPlus,
            });
            const fields = [
                `${waffe.name}`,
                `${roll.total}`,
                `${waffe.data.data.fertigkeit}`,
                `${waffe.data.data.ticks}`,
                `${waffe.data.data.schaden}`,
                `${waffe.data.data.merkmale}`,
            ];
            return {
                fields,
                roll: roll.total,
                rollInfo: JSON.stringify({
                    explanation: roll.explanation,
                    ticks: waffe.data.data.ticks + tickPlus.total,
                    ticksExplanation: `WGS ${waffe.data.data.ticks} + ${tickPlus.explanation}`,
                    name: waffe.name,
                    damage: waffe.data.data.schaden,
                }),
                equipped: waffe.data.data.isEquipped,
            };
        };
        return PlayerDataService.getTableData(actor, mods, "waffe" /* Waffe */, tableFields, getFields);
    }
    static getSchilde(actor, mods) {
        const tableFields = [
            "splittermond.inventar.schilde.name",
            "splittermond.inventar.schilde.wert",
            "splittermond.inventar.schilde.fertigkeit",
            "splittermond.inventar.schilde.vtd",
            "splittermond.inventar.schilde.merkmale",
        ];
        const getFields = (schild) => {
            const roll = CalculationService.getWaffeOrSchildValue(actor, schild.data.data, mods, schild.name);
            const fields = [
                `${schild.name}`,
                `${roll.total}`,
                `${schild.data.data.fertigkeit}`,
                `${schild.data.data.VTD}`,
                `${schild.data.data.merkmale}`,
            ];
            return {
                fields,
                roll: roll.total,
                rollInfo: JSON.stringify({
                    explanation: roll.explanation,
                    name: schild.name
                }),
                equipped: schild.data.data.isEquipped,
            };
        };
        return PlayerDataService.getTableData(actor, mods, "schild" /* Schild */, tableFields, getFields);
    }
    static getRuestungen(actor, mods) {
        const tableFields = [
            "splittermond.inventar.ruestungen.name",
            "splittermond.inventar.ruestungen.vtd",
            "splittermond.inventar.ruestungen.sr",
            "splittermond.inventar.ruestungen.beh",
            "splittermond.inventar.ruestungen.tick",
            "splittermond.inventar.ruestungen.merkmale",
        ];
        const getFields = (ruestung) => {
            const fields = [
                `${ruestung.name}`,
                `${ruestung.data.data.VTD}`,
                `${ruestung.data.data.SR}`,
                `${ruestung.data.data.BEH}`,
                `${ruestung.data.data.tickPlus}`,
                `${ruestung.data.data.merkmale}`,
            ];
            return {
                fields,
                equipped: ruestung.data.data.isEquipped,
            };
        };
        return PlayerDataService.getTableData(actor, mods, "ruestung" /* Ruestung */, tableFields, getFields);
    }
    static getBenutzbares(actor, mods) {
        const tableFields = [
            "splittermond.inventar.benutzbares.name",
            "splittermond.inventar.benutzbares.ticks",
            "splittermond.inventar.benutzbares.begrenzt",
            "splittermond.inventar.benutzbares.anzahl",
        ];
        const getFields = (benutzbar) => {
            const fields = [
                `${benutzbar.name}`,
                `${benutzbar.data.data.ticks}`,
                `${benutzbar.data.data.wirdVerbraucht}`,
                `${benutzbar.data.data.anzahl}`,
            ];
            return {
                fields,
                rollInfo: JSON.stringify({
                    ticks: benutzbar.data.data.ticks,
                    name: benutzbar.name,
                }),
            };
        };
        return PlayerDataService.getTableData(actor, mods, "benutzbar" /* Benutzbar */, tableFields, getFields);
    }
    static getSonstiges(actor, mods) {
        const tableFields = [
            "splittermond.inventar.sonstiges.name",
            "splittermond.inventar.sonstiges.wert",
            "splittermond.inventar.sonstiges.gewicht",
            "splittermond.inventar.sonstiges.anzahl",
        ];
        const getFields = (gegenstand) => {
            const fields = [
                `${gegenstand.name}`,
                `${gegenstand.data.data.wertInTellaren}`,
                `${gegenstand.data.data.gewicht}`,
                `${gegenstand.data.data.anzahl}`,
            ];
            return {
                fields,
            };
        };
        return PlayerDataService.getTableData(actor, mods, "gegenstand" /* Gegenstand */, tableFields, getFields);
    }
    static getZauber(actor, mods) {
        const tableFields = [
            "splittermond.zauber.name",
            "splittermond.zauber.schule",
            "splittermond.zauber.wert",
            "splittermond.zauber.schwierigkeit",
            "splittermond.zauber.fokus",
            "splittermond.zauber.zauberdauer",
            "splittermond.zauber.reichweite",
            "splittermond.zauber.verstaerkung",
        ];
        const getFields = (zauber) => {
            const roll = CalculationService.getFertigkeitsValue(actor, zauber.data.data.fertigkeit, mods);
            const fields = [
                `${zauber.name}`,
                `${zauber.data.data.fertigkeit}`,
                `${roll.total}`,
                `${zauber.data.data.schwierigkeitString}`,
                `${buildFokusString(zauber.data.data)}`,
                `${zauber.data.data.zauberdauerString}`,
                `${zauber.data.data.reichweiteString}`,
                `${zauber.data.data.verstaerkung}`,
            ];
            return {
                fields,
                roll: roll.total,
                rollInfo: JSON.stringify({
                    ticks: zauber.data.data.ticks,
                    fokusCost: buildFokusString(zauber.data.data),
                    name: zauber.name,
                    explanation: roll.explanation,
                    damage: zauber.data.data.schaden,
                }),
            };
        };
        return PlayerDataService.getTableData(actor, mods, "zauber" /* Zauber */, tableFields, getFields);
    }
    static getMeisterschaften(actor, mods) {
        const tableFields = [
            "splittermond.meisterschaft.name",
            "splittermond.meisterschaft.fertigkeit",
            "splittermond.meisterschaft.maneuver",
        ];
        const getFields = (ms) => {
            const fields = [
                ms.name,
                ms.data.data.fertigkeit,
                ms.data.data.maneuverEffekt,
            ];
            const isManeuver = ms.data.data.isManeuver;
            let roll = undefined;
            if (isManeuver) {
                const weapon = ms.data.data.useActiveWeapon
                    ? actor.items.find((i) => i.type === "waffe" /* Waffe */ &&
                        i.data.data.isEquipped)
                    : undefined;
                roll = !ms.data.data.useActiveWeapon
                    ? CalculationService.getFertigkeitsValue(actor, ms.data.data.fertigkeit, mods)
                    : weapon
                        ? CalculationService.getWaffeOrSchildValue(actor, weapon.data.data, mods, weapon.name)
                        : { total: 0, explanation: "Keine ausgerüstete Waffe." };
            }
            return {
                fields,
                roll: roll ? roll.total : undefined,
                rollInfo: roll
                    ? JSON.stringify({
                        name: ms.name,
                        explanation: roll.explanation,
                        maneuver: {
                            egCost: ms.data.data.egCost,
                            effekt: ms.data.data.maneuverEffekt,
                        },
                    })
                    : undefined,
            };
        };
        return PlayerDataService.getTableData(actor, mods, "meisterschaft" /* Meisterschaft */, tableFields, getFields);
    }
    static getStaerken(actor, mods) {
        const tableFields = ["splittermond.staerke.name"];
        const getFields = (ms) => {
            const fields = [ms.name];
            return {
                fields,
            };
        };
        return PlayerDataService.getTableData(actor, mods, "staerke" /* Staerke */, tableFields, getFields);
    }
    static getSchwaechen(actor, mods) {
        const tableFields = ["splittermond.schwaeche.name"];
        const getFields = (ms) => {
            const fields = [ms.name];
            return {
                fields,
            };
        };
        return PlayerDataService.getTableData(actor, mods, "schwaeche" /* Schwaeche */, tableFields, getFields);
    }
    static getZustaende(actor, mods) {
        const tableFields = ["splittermond.zustand.name"];
        const getFields = (ms) => {
            const fields = [ms.name];
            return {
                fields,
            };
        };
        return PlayerDataService.getTableData(actor, mods, "zustand" /* Zustand */, tableFields, getFields);
    }
    static getMerkmale(actor, mods) {
        const tableFields = ["splittermond.merkmal.name"];
        const getFields = (ms) => {
            const fields = [ms.name];
            return {
                fields,
            };
        };
        return PlayerDataService.getTableData(actor, mods, "merkmal" /* Merkmal */, tableFields, getFields);
    }
    static getResourcen(actor, mods) {
        const tableFields = [
            "splittermond.resource.name",
            "splittermond.resource.punkte",
        ];
        const getFields = (ms) => {
            const fields = [ms.name, `${ms.data.data.punkte}`];
            return {
                fields,
            };
        };
        return PlayerDataService.getTableData(actor, mods, "resource" /* Resource */, tableFields, getFields);
    }
    static getMondzeichen(actor, mods) {
        var _a;
        const mondzeichen = actor.items.find((i) => i.type === "mondzeichen" /* Mondzeichen */);
        return Object.assign(Object.assign({}, ((_a = mondzeichen === null || mondzeichen === void 0 ? void 0 : mondzeichen.data.data) !== null && _a !== void 0 ? _a : {})), { name: mondzeichen === null || mondzeichen === void 0 ? void 0 : mondzeichen.name, img: mondzeichen === null || mondzeichen === void 0 ? void 0 : mondzeichen.img });
    }
    static getTableData(actor, modifiers, type, tableFields, getFields) {
        const tableData = actor.items
            .filter((i) => (typeof type === "string" ? i.type === type : type(i)))
            .map((item) => (Object.assign({ id: item.id }, getFields(item))));
        return {
            tableFields,
            tableData,
        };
    }
    static getViewSpecificData(actor, modifiers, attributes, derivedAttributes) {
        const woundLevelModifier = ModifierService.totalMod(modifiers, null, {
            modType: ModifierType.WoundLevels,
        });
        const maxHealth = derivedAttributes.LP.total * (5 + woundLevelModifier);
        const health = {
            current: maxHealth -
                actor.data.data.healthErschoepft -
                actor.data.data.healthKanalisiert -
                actor.data.data.healthVerzehrt,
            max: maxHealth,
            asString: CalculationService.toEKVString(actor.data.data.healthErschoepft, actor.data.data.healthKanalisiert, actor.data.data.healthVerzehrt),
        };
        const maxFokus = derivedAttributes.FO.total;
        const fokus = {
            current: maxFokus -
                actor.data.data.fokusErschoepft -
                actor.data.data.fokusKanalisiert -
                actor.data.data.fokusVerzehrt,
            max: derivedAttributes.FO.total,
            asString: CalculationService.toEKVString(actor.data.data.fokusErschoepft, actor.data.data.fokusKanalisiert, actor.data.data.fokusVerzehrt),
        };
        return {
            health,
            fokus,
        };
    }
}
