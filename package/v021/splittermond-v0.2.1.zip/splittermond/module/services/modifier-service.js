import { ModifierType } from "../models/items/modifier.js";
import { FertigkeitType } from "../models/items/fertigkeit.js";
export class ModifierService {
    static getModifiers(actor) {
        const result = {
            byType: new Map(),
            byTarget: new Map(),
            byItemType: new Map(),
        };
        const sorted = ModifierService.sortItems(actor.items);
        ModifierService.addMods(result, "rasse" /* Rasse */, sorted, (v) => v.modifier);
        ModifierService.addMods(result, "abstammung" /* Abstammung */, sorted, (v) => v.modifier);
        ModifierService.addMods(result, "kultur" /* Kultur */, sorted, (v) => v.modifier);
        ModifierService.addMods(result, "meisterschaft" /* Meisterschaft */, sorted, (v) => v.modifier);
        ModifierService.addMods(result, "merkmal" /* Merkmal */, sorted, (v) => v.modifier);
        ModifierService.addMods(result, "schwaeche" /* Schwaeche */, sorted, (v) => v.modifier);
        ModifierService.addMods(result, "staerke" /* Staerke */, sorted, (v) => v.modifier);
        ModifierService.addMods(result, "zustand" /* Zustand */, sorted, (v) => v.modifier);
        ModifierService.addMods(result, "ruestung" /* Ruestung */, sorted, (v) => ModifierService.getRuestungModifier(v, sorted));
        ModifierService.addMods(result, "schild" /* Schild */, sorted, (v) => ModifierService.getSchildModifier(v, sorted));
        return result;
    }
    static totalModWithExplanation(mods, target, opts) {
        var _a, _b, _c;
        let modifiers = target != null && target.length > 0
            ? (_a = mods.byTarget.get(target)) !== null && _a !== void 0 ? _a : []
            : (opts === null || opts === void 0 ? void 0 : opts.modType) != null && opts.modType.length > 0
                ? (_b = mods.byType.get(opts.modType)) !== null && _b !== void 0 ? _b : []
                : (opts === null || opts === void 0 ? void 0 : opts.itemType) != null && opts.itemType.length > 0
                    ? (_c = mods.byItemType.get(opts.itemType)) !== null && _c !== void 0 ? _c : []
                    : [];
        if (opts) {
            modifiers = modifiers.filter((mod) => {
                return (((opts === null || opts === void 0 ? void 0 : opts.itemType) == null || (opts === null || opts === void 0 ? void 0 : opts.itemType) === mod.source.type) &&
                    ((opts === null || opts === void 0 ? void 0 : opts.modType) == null || (opts === null || opts === void 0 ? void 0 : opts.modType) === mod.modifier.type));
            });
        }
        const total = modifiers.reduce((accu, curr) => accu + curr.modifier.value, 0);
        const explanation = modifiers.map((curr) => `${curr.source.name} (${curr.modifier.value})`).join(' + ');
        return {
            total,
            explanation
        };
    }
    static totalMod(mods, target, opts) {
        return ModifierService.totalModWithExplanation(mods, target, opts).total;
    }
    static sortItems(items) {
        return items.reduce((map, item) => {
            var _a;
            if (!item) {
                return map;
            }
            const collection = (_a = map.get(item.type)) !== null && _a !== void 0 ? _a : [];
            collection.push(item);
            map.set(item.type, collection);
            return map;
        }, new Map());
    }
    static addMods(mods, itemType, sortedItems, getModifierField) {
        var _a;
        const items = (_a = sortedItems.get(itemType)) !== null && _a !== void 0 ? _a : [];
        const modifiers = ModifierService.flatten(items.map((i) => getModifierField(i.data.data).map((m) => ({
            modifier: m,
            source: i,
        }))));
        modifiers.forEach((modifier) => {
            var _a, _b, _c;
            const byType = (_a = mods.byType.get(modifier.modifier.type)) !== null && _a !== void 0 ? _a : [];
            byType.push(modifier);
            mods.byType.set(modifier.modifier.type, byType);
            const byTarget = (_b = mods.byTarget.get(modifier.modifier.target)) !== null && _b !== void 0 ? _b : [];
            byTarget.push(modifier);
            mods.byTarget.set(modifier.modifier.target, byTarget);
            const byItemType = (_c = mods.byItemType.get(modifier.source.type)) !== null && _c !== void 0 ? _c : [];
            byItemType.push(modifier);
            mods.byItemType.set(modifier.source.type, byItemType);
        });
    }
    static flatten(arr) {
        return arr.reduce((accu, curr) => {
            accu.push(...curr);
            return accu;
        }, []);
    }
    static getRuestungModifier(v, sorted) {
        if (!v.isEquipped) {
            return [];
        }
        const tickPlus = {
            type: ModifierType.TickPlus,
            target: ModifierType.TickPlus,
            value: v.tickPlus,
        };
        const vtdModifier = {
            type: ModifierType.Attribute,
            target: "VTD",
            value: v.VTD,
        };
        return [
            tickPlus,
            ...ModifierService.getBehModifiers(v.BEH, sorted),
            vtdModifier,
        ];
    }
    static getSchildModifier(v, sorted) {
        if (!v.isEquipped) {
            return [];
        }
        const vtdModifier = {
            type: ModifierType.Attribute,
            target: "VTD",
            value: v.VTD,
        };
        return [vtdModifier, ...ModifierService.getBehModifiers(v.BEH, sorted)];
    }
    static getBehModifiers(beh, sorted) {
        var _a;
        const bewSkills = ((_a = sorted.get("fertigkeit" /* Fertigkeit */)) !== null && _a !== void 0 ? _a : []).filter((f) => [f.data.data.attributEins, f.data.data.attributZwei].includes("BEW") &&
            f.data.data.type === FertigkeitType.Allgemein);
        const behModifiers = bewSkills.map((skill) => ({
            type: ModifierType.Fertigkeit,
            target: skill.name,
            value: -1 * beh,
        }));
        const behGswModifier = {
            type: ModifierType.Attribute,
            target: "GSW",
            value: Math.round(beh / 2),
        };
        return [...behModifiers, behGswModifier];
    }
}
